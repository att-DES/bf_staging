# Sencha Drop 2 Release Notes

This drop introduces the rest of the AT&T APIs to the server side library.

Ruby Changes:

Defect 843:  Fixed.   Directory structure up to date in Getting Started guide.
Defect 847:  Fixed.   Updated documentation.
Defect 848:  Fixed.   Updated documentation.
Defect 849:  Fixed.   Directory removed
Defect 938:  Fixed.   Updated documentation.
Defect 955:  Fixed.   Added extra debug info to lib/sencha/service_provider/att/base.rb initialize method.
Defect 957:  Fixed.   Added extra debug info for file and linenumber to lib/sencha/service_provider/att/base.rb and lib/sencha/service_provider/att/service.rb
Defect 958:  Fixed.   See defect 957.
Defect 959:  Invalid. Cannot find docs for sending multiple SMS.
Defect 960:  Fixed.   Raise an exception if no shortcode is set on lib/sencha/service_provider/att/base.rb
Defect 961:  Fixed.   Raise an exception if no host is set on lib/sencha/service_provider/att/base.rb
Defect 963:  Invalid. The registration ID is the same as the shortcode which is specified at application initialization time
Defect 977:  Fixed.   Made accuracy a required variable in lib/sencha/service_provider/location.rb and changed on the client side
Defect 981:  Fixed.   Debug information available from Defect 957 + 958 fixes.
Defect 1025: Fixed.   Added 'priority' parameter to Send MMS in lib/sencha/service_provider/att/mms.rb
Defect 1026: Fixed.   Added ability to specify more recipients with a comma separated list. Changed lib/sencha/service_provider/att/mms.rb
Defect 1105: Fixed.   Altered WAP signature in lib/sencha/service_provider/wap.rb and example call in app.rb '/wap_push'
Defect 1107: Fixed.   Wap push now accepts a comma seaparated list of MSISDNs. Changes to lib/sencha/service_provider/att/wap.rb
Defect 1108: Fixed.   See defect 1105
Defect 1120: Fixed.   Added a parameter for Subject in lib/sencha/service_provider/mms.rb, renamed file_type to mime_type and updated app.rb send_mms
Defect 1123: Fixed.   Added documentation to each method of the server side API in lib/sencha/service_provider/att

## Known Issues

Sending a new payment request over JSON when the merchant ID has not been approved by Amdocs results in an HTML response. Should be JSON.

Sending any type of request over JSON when the application has not been authorized for that service results in an XML error response - should be JSON.

oAuth does not respond correctly to redirectUri. It redirects to the url submitted when registering the application. IP addresses cannot currently be used for the oAuth redirection URI which is a problem for developers wishing to use a local IP address with which to develop.

Payments need a valid DNS entry return URL to process a new transaction. Does not work with IP addresses.

New Payment Redirect URL errors appear as XML. Needs to be nicely formatted HTML as it is consumer facing.

New payment and subscription errors should be more verbose - 'success false' is not enough information. Especially relating to missing fields.

Docs say the field 'productDescription' is required for payments but should just be 'description'

Docs say 'externalMerchantTransactionID' is optional but it is required

An Invalid location request (eg wrong phone number) results in an XML error despite making a request with content type JSON:
https://test-api.att.com/1/devices/tel:9413802158/location?requestedAccuracy=100000&access_token=debc7c1413d9e876b92abf8b326584fd

Subscription Status is currently working with the same URL as payment status. Subscription status URL not working?

Occasionally a new payment will result in a DNS error when showing the Payment redirect URL. No way to get back to app if error is shown.

Sending an SMS to an un-provisioned number results in the following error:
{"requestError": { "serviceException": { "messageId": "SVC0001", "text": "A service error occurred. Error code is %1", "variables": "SMPP-0066"  } }}

Error receiving SMS:
{"requestError": { "serviceException": { "messageId": "SVC0002", "text": "Invalid input value for message part %1  ", "variables" : "sender Address " }}}.

New Payments and Subscription result in an XML error if there are stale cookies present from an older transaction. Must completely clear cookies and browser cache to solve.
<fault>
  <faultstring>Fault raised in a policy</faultstring>
  <detail>
    <errorcode>31326</errorcode>
    <trace>
        Fault Name: RaiseInvalidSession
        Error Type: MessageRouter
        Description: Fault raised in a policy
        Service: paymentAOC
        Endpoint: aoc_client
        Operation (Client):PayAoc
        FlowTransitionState : Client_Request_User_Error
        Policy : ValidateSessionIdPolicy
        RaiseFaultAssertion
    </trace>
  </detail>
</fault>

Invalid SSL Certificate when using oauth

