module Sencha
  module ServiceProvider
    module Att

      # Creates a new payment
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {Hash} options A hash of payment options. Options should include:
      #    {Number} amount The payment amount
      #    {String} product_id A product identifier
      #    {String} transaction_id A unique transaction ID
      #    {String} description A description of the payment
      def createPayment(access_token, options)

        url = "#{@base_url}/1/payments/transactions?access_token=#{access_token}"

        json_post(url, payment_options(options))
      end

      # Creates a new subscription
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {Hash} options A hash of subscription options. Options should include:
      #    {Number} amount The payment amount
      #    {String} product_id A product identifier
      #    {String} transaction_id A unique transaction ID
      #    {String} description A description of the payment
      #    {Number} recurrences The number of times the subscription should repeat
      #    {String} recurrence_period The period of recurrence. Valid options are WEEKLY, MONTHLY or YEARLY
      #    {Number} recurrence_interval The interval between recurrences
      #    {String} subscription_id A unique ID for this subscription
      def createSubscription(access_token, options)

        url = "#{@base_url}/1/payments/transactions?access_token=#{access_token}"

        json_post(url, payment_options(options, true))
      end

      # Queries the status of a payment
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} transaction_id The ID returned by the 'createPayment' method
      def paymentStatus(access_token, transaction_id)
        json_get("#{@base_url}/1/payments/transactions/#{transaction_id}?access_token=#{access_token}")
      end

      # Queries the status of a subscription
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} transaction_id The ID returned by the 'createSubscription' method
      def subscriptionStatus(access_token, subscription_id)
        json_get("#{@base_url}/1/payments/transactions/#{subscription_id}?access_token=#{access_token}")
      end

      # Issues a refund for a payment
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {Hash} options A hash of refund options. Options should include:
      #    {String} transaction_id The unique transaction ID
      #    {String} reason A reason for the refund
      #    {Number} code A 'reason code' for the refund as specified by AT&T. Use 1 for a default value
      def paymentRefund(access_token, options)

        %w(transaction_id reason code).each do |arg|
          raise ArgumentError, "#{arg} must be set" unless options[arg.to_sym]
        end

        url = "#{@base_url}/1/payments/transactions/#{options[:transaction_id]}?access_token=#{access_token}&action=refund"

        json_post(url, {
          :refundReasonText => options[:reason],
          :refundReasonCode => options[:code]
        })
      end

      private

        def payment_options(options, subscription = false)

          %w(amount description product_id transaction_id).each do |arg|
            raise ArgumentError, "#{arg} must be set" unless options[arg.to_sym]
          end

          if subscription
            %w(recurrences recurrence_period recurrence_interval subscription_id).each do |arg|
              raise ArgumentError, "#{arg} must be set" unless options[arg.to_sym]
            end
          end

          response = {
            :amount => options[:amount],
            :category => 1,
            :channel => 'MOBILE_WEB',
            :currency => 'USD',
            :description => options[:description],
            :merchantProductID => options[:product_id],
            :merchantApplicationID => @client_id,
            :externalMerchantTransactionID => options[:transaction_id],
            :purchaseOnNoActiveSubscription => false,
            :merchantCancelRedirectUrl => "#{@local_server}/payments/cancel",
            :merchantFulfillmentRedirectUrl => "#{@local_server}/payments/deliver",
            :transactionStatusCallbackUrl => "#{@local_server}/payments/notify",
            :autoCommit => true
          }

          if subscription
            response = response.merge({
              :subscriptionRecurringNumber => options[:recurrences],
              :subscriptionRecurringPeriod => options[:recurrence_period],
              :subscriptionRecurringPeriodAmount => options[:recurrence_interval],
              :merchantSubscriptionIdList => options[:subscription_id]
            })
          end

          response

        end

    end
  end
end