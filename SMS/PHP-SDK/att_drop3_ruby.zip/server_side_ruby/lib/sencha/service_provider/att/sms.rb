# This module contains methods pertaining to the SMS api
module Sencha
  module ServiceProvider
    module Att

      # Sends an SMS to a recipient
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} tel The MSISDN of the recipient
      #  {String} message The text of the message to send
      def sendSms(access_token, tel, message)

        url = "#{@base_url}/1/messages/outbox/sms?access_token=#{access_token}"

        json_post(url, {
          :address => "tel:#{tel}",
          :message => message
        })
      end

      # Sends an SMS to a recipient
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} tel The MSISDN of the recipient
      #  {String} message The text of the message to send
      def sendSmsGsma(access_token, tel, message)

        url = "#{@base_url}/gsma/1/smsmessaging/outbound/#{@shortcode}/requests?access_token=#{access_token}"

        json_post(url, {
          :address => "tel:#{tel}",
          :message => message
        })
      end

      # Check the status of a sent SMS
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} sms_id The unique SMS ID as retrieved from the response of the sendSms method
      def smsStatus(access_token, sms_id)
        json_get "#{@base_url}/1/messages/outbox/sms/#{sms_id}?access_token=#{access_token}"
      end

      # Retrieves a list of SMSes sent to the application's short code
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      def receiveSms(access_token)
        json_get "#{@base_url}/1/messages/inbox/sms?access_token=#{access_token}&registrationID=#{@shortcode}&format=json"
      end

    end
  end
end
