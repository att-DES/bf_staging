module Sencha
  module ServiceProvider
    module Att

      # Given a scope, return the corresponding AT&T oAuth URL
      #
      # Parameters:
      #  {String} scope a comma separated list of services that teh app requires access to
      def oauthUrl(scope)
        "#{@base_url}/oauth/authorize?scope=#{scope}&client_id=#{@client_id}&type=web_server&redirect_uri=#{@local_server}/auth/callback"
      end

      # Retrieves and access token from AT&T once the user has authorised the application and returned with an auth code
      #
      # Parameters:
      #   {String} code The code
      def getToken(code)
        json_get "#{@base_url}/oauth/access_token?client_id=#{@client_id}&client_secret=#{@client_secret}&code=#{code}"
      end

    end
  end
end