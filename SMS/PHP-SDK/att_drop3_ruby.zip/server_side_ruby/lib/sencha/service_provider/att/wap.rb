module Sencha
  module ServiceProvider
    module Att

      # Sends a WAP Push to a device
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} tel A comma separated list of MSISDNs of the recipients
      #  {String} subject The subject of the MMS
      #  {String} href The URL of the resource to send the device
      #  {String} message The message to send
      #  {String} priority The priority of the message
      def wapPush(access_token, tel, subject, href, message, priority)

        mimeContent = Sencha::ServiceProvider::MiniMime.new

        recipients = tel.split(",").join('</address><address>')

        mimeContent.add_content(
          :type => 'text/xml',
          :content =>
            '<wapPushRequest>' + "\n" +
            '  <addresses>' + "\n" +
            '     <address>tel:'+recipients+'</address>' + "\n" +
            '  </addresses>' + "\n" +
            '  <subject>' + subject + '</subject>' + "\n" +
            '  <priority>' + priority + '</priority>' + "\n" +
            '</wapPushRequest>'
        )

        mimeContent.add_content(
          :type => 'text/xml',
          :content =>
            'Content-Disposition: form-data; name="PushContent"' +  "\n" +
            'Content-Type: text/vnd.wap.si' +  "\n" +
            'Content-Length: 12' +  "\n" +
            'X-Wap-Application-Id: x-wap-application:wml.ua' +  "\n" +
            '' +  "\n" +
            '<?xml version ="1.0"?>' +  "\n" +
            '<!DOCTYPE si PUBLIC "-//WAPFORUM//DTD SI 1.0//EN" "">http://www.wapforum.org/DTD/si.dtd">' +  "\n" +
            '<si>' +  "\n" +
            '   <indication href="' + href + '" si-id="1">' +  "\n" +
            '     ' + message +  "\n" +
            '   </indication>' +  "\n" +
            '</si>'
        )

        url = "#{@base_url}/1/messages/outbox/wapPush?access_token=#{access_token}"
        json_post_mime(url, mimeContent)

      end

    end
  end
end