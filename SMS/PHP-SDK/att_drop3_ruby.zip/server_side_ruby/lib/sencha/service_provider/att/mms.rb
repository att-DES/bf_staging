module Sencha
  module ServiceProvider
    module Att

      # Sends an MMS to a recipient
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} tel Comma separated list of MSISDN of the recipients
      #  {String} file_mime_type The MIME type of the content, eg: image/jpg
      #  {String} file_name The name of the file, eg logo.jpg
      #  {Binary} file_contents The contents of the file. Will be converted to Base64
      #  {String} priority Can be "Default", "Low", "Normal" or "High"
      #  {String} subject The subject line for the MMS
      def sendMms(access_token, tel, file_mime_type, file_name, file_contents, priority, subject)

        mimeContent = MiniMime.new
        recipients = tel.split(",").join('", "address": "tel":"')

        mimeContent.add_content(
          :type => 'application/json',
          :content => '{ "address" : "tel:' + recipients + '", "subject" : "' + subject + '", "priority": "' + priority + '" }'
        )

        mimeContent.add_content(
          :type => file_mime_type,
          :headers => {
             'Content-Transfer-Encoding' => 'base64',
             'Content-Disposition' => 'attachment; name="' + file_name + '"'
          },
          :content_id => '<' + file_name + '>',
          :content => Base64.encode64(file_contents)
        )

        url = "#{@base_url}/1/messages/outbox/mms?access_token=#{access_token}"
        json_post_mime(url, mimeContent)
      end

      # Queries the status of a sent MMS
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} mms_id The ID of the MMS as received in the returned data when sending an MMS
      def mmsStatus(access_token, mms_id)
        json_get "#{@base_url}/1/messages/outbox/mms/#{mms_id}?access_token=#{access_token}"
      end

    end
  end
end



