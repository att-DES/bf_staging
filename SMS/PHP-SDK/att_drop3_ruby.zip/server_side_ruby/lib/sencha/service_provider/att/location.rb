module Sencha
  module ServiceProvider
    module Att

      # Return location info for a device
      #
      # Parameters:
      #  {String} access_token The oAuth access token
      #  {String} tel MSISDN of the device to locate
      def deviceLocation(access_token, tel, accuracy)
        json_get "#{@base_url}/1/devices/tel:#{tel}/location?requestedAccuracy=#{accuracy}&access_token=#{access_token}"
      end

    end
  end
end
