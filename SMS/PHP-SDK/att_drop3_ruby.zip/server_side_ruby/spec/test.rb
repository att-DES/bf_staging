# This script exercises the Server Side Ruby API.
#
# Usage: ruby spec/test.rb
#

require 'rubygems'
require 'sinatra'
require 'json'
require './lib/sencha/service_provider/base'

# Store Sinatra sessions in memory rather than client cookies
use Rack::Session::Pool

# Set up the ATT library with the Client application ID and secret. These will have been
# given to you when you registered your application on the AT&T developer site.
@@att = Sencha::ServiceProvider::Base.init(
  :provider => :att,
  :client_id => 'c4c9084c6e9cb6ca01886a15e7dfd486',
  :client_secret => 'a0725b93040cfe0e',
  :local_server => "http://192.168.1.153:4567"
)

Thread.new do

  agent = Mechanize.new

  puts "Starting tests. Requesting Auth URL"

  auth_url = @@att.oauth_url('PAYMENT')

  puts "Got #{auth_url}. Fetching..."

  page = agent.get(auth_url)

  search_form = page.form_with(:name => "login")
  search_form.field_with(:name => "loginid").value = 'mohamadWA_bf1@yahoo.com'
  search_form.field_with(:name => "password").value = 'welcome1'

  puts "Attempting to login"
  login_result = agent.submit(search_form)

  puts "Authorizing application"
  auth_form = login_result.form_with(:name => 'authorize')
  auth_result = agent.submit(auth_form)

end

get '/auth/callback' do

  response = @@att.get_token(params[:code])

  if response.error?
    puts "ERROR"
    Process.exit!
  else
    session['token'] = response.token
    puts "OK access_token: #{response.token}"

    response = @@att.create_payment \
      :access_token => session['token'],
      :transaction_id => 'transaction-123',
      :product_id => 'sencha-widget-1',
      :amount => 0.04,
      :description => 'Sencha Touch Widget'

    if response.error?
      puts "Payment Error: #{response.error}"
      Process.exit!
    else
      puts "Payment redirect URL: #{response.redirect_url}"

      agent = Mechanize.new

      authorisePage = agent.get(response.redirect_url)

      puts "Submitting payment authorization"

      # Assume first form on page is confirm form
      confirmForm = authorisePage.forms[0]
      authResult = agent.submit(confirmForm)

      puts "Looking for redirect link"

      begin
        confirmURL = authResult.search(".button_left")[0]['onclick']
        if confirmURL.match(/txid=([0-9]+)/)
          puts "Got transaction ID #{$1}"
        else
          puts "Couldn't find redirect link"
        end
      rescue Exception => e
        puts "Couldn't search for redirect link #{e}"
      end

      Process.exit!

    end

  end
end
