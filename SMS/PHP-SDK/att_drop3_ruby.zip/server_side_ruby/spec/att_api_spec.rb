# Ignore this file, not currently used.

require './lib/sencha/service_provider/base'

describe AttApi, '#initialize' do
  
  def working_args
    {
      :client_id => '456', 
      :client_secret => '123'
    }
  end
  
  it "expects a config argument" do
    
    lambda { 
      AttApi.new
    }.should raise_error(ArgumentError)
    
  end
  
  it "expects a client_id" do

    lambda { 
      AttApi.new( working_args.reject{|k, v| k == :client_id } )
    }.should raise_error(ArgumentError, "no client_id specified")
    
  end
  
  it "expects a client_secret" do

    lambda { 
      AttApi.new( working_args.reject{|k, v| k == :client_secret } )
    }.should raise_error(ArgumentError, "no client_secret specified")
    
  end
  
  it "does not raise an error with a valid argument" do

    lambda { 
      AttApi.new working_args
    }.should_not raise_error
    
  end
  
end

describe AttApi, '#authURL' do

  before(:all) do
    @att_api = AttApi.new({
      :client_id => '456', 
      :client_secret => '123'
    })
  end
  
  it "should return a correct URL with all scopes" do
    
    # TL,DC,WAP,SMS,MMS,PAYMENT,SPEECH
    
    @att_api.authURL(:scope => [:payments, :location, :device_info, :sms, :mms, :speech]).should equal("")
    
  end
  
end

