
# This is an example Sinatra application demonstraiting both server and client components
# of the Sencha library for interacting with AT&T's HTML APIs

require 'rubygems'
require 'sinatra'
require 'json'
require 'crack'

require './lib/sencha/service_provider/base'

# Store Sinatra sessions in memory rather than client side cookies
use Rack::Session::Pool

# Put the application in 'debug' mode. Set to `false` to disable debugging.
Sencha::DEBUG = :all

# Set up the ATT library with the Client application ID and secret. These will have been
# given to you when you registered your application on the AT&T developer site.

@@att = Sencha::ServiceProvider::Base.init(
  :provider => :att,

  :client_id => '615c78362f2ada9244d221fb19e0d8bb', # Production Sencha
  :client_secret => '6a8edc0a5cd928f9',

  # This is the main endpoint through which all API requests are made
  :host => 'https://api.att.com',

  # The address of the locally running server. This is used when a callback URL is
  # required when making a request to the AT&T APIs.
  :local_server => 'http://localhost.org:4567',

  # The shortcode is the SMS number used when sending and receiving SMS and MMS messages.
  :shortcode => '22527003'
)

# The root URL starts off the Sencha Touch application. On the desktop, any Webkit browser
# will work, such as Google Chrome or Apple Safari. It's best to use desktop browsers
# when developing and debugging your application due to the superior developer tools such
# as the Web Inspector.
get '/' do
  erb :index
end

# Generate the oauth redirect URL depending on the scope requested by the client.
# The scope is specified as a parameter in the GET request and passed to the provider
# library to obtain the appropriate Oauth URL
get '/auth/url' do

  url = @@att.oauthUrl(params[:scope])

  # Set the Content-Type header of the response to application/json
  content_type :json

  # The last value within a Sinatra block is the content of the response, in this case
  # a JSON object with a property called `redirect`
  { :redirect => url }.to_json
end

# Return a json object with either 'true' or 'false' depending on whether an
# access_token has been set. This indicates whether the user is logged in.
get '/auth/check' do

  content_type :json
  { :authorized => session['token'] ? true : false }.to_json
end

# Once the user has logged in with their credentials, they get redirected to this URL
# with a 'code' parameter. This is exchanged for an access token which can be used in any
# future calls to the AT&T APIs
get '/auth/callback' do

  if !params[:code]
    # `erb` is a method which renders an HTML template, located in ./views/error.erb
    # passing local variables which can be accessed from inside the template
    erb :error, :locals => { :error => "No auth code" }
    return
  end

  response = @@att.getToken(params[:code])

  if response.error?
    erb :error, :locals => { :error => response.error.to_json }
  else
    # Store the auth token in the session for use in future API calls
    session['token'] = response.data['access_token']

    # Render the `callback` template in ./views/callback.erb
    # This template will attempt to run the `successCallback` function
    # in the parent iframe.
    erb :callback
  end
end

# This endpoint demonstrates creating a new payment from the server side. Typically, this
# call would be made as part of the checkout process, for example when the customer clicks
# a 'Checkout' button from within the app.
post '/payments' do

  response = @@att.createPayment(session['token'], {
    :product_id => 'SenchaProduct60214',
    :amount => 2.22,
    :description => 'Sencha Description',
    :transaction_id => "SenchaTransId#{(Time.now.to_f * 1000).to_i}"
  })

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  elsif response.data['redirectUrl'] == ''
    { :error => "Payment Error" }.to_json
  else
    session['payment_id'] = response.data['trxID']
    { :redirect => response.data['redirectUrl'] }.to_json
  end
end

get '/payment_status' do

  response = @@att.paymentStatus(session['token'], session['payment_id'])

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  else
    response.data.to_json
  end
end

post '/subscriptions' do

  response = @@att.createSubscription(session['token'], {
    :product_id => 'SenchaProduct60214',
    :amount => 1.29,
    :description => 'Sencha Description',
    :transaction_id => "SenchaTransId#{(Time.now.to_f * 1000).to_i}",

    :recurrences => 99999,
    :recurrence_period => 'MONTHLY',
    :recurrence_interval => 1,
    :subscription_id => "SEN#{(Time.now.to_f * 1000).to_i}"
  })

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  elsif response.data['redirectUrl'] == ''
    { :error => "Payment Error" }.to_json
  else
    session['subscription_id'] = response.data['trxID']
    { :redirect => response.data['redirectUrl'] }.to_json
  end
end

post '/payment_refund' do

  response = @@att.paymentRefund(session['token'], {
    :transaction_id => session['payment_id'],
    :reason => "Customer was not happy",
    :code => 1
  })

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  else
    response.data.to_json
  end
end

get '/subscription_status' do

  response = @@att.subscriptionStatus(session['token'], session['subscription_id'])

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  else
    response.data.to_json
  end
end

post '/wap_push' do

  response = @@att.wapPush(session['token'], '4252335893', 'WAP', 'http://wap.uni-wise.com/hswap/zh_1/index.jsp?MF=N&Dir=23724', 'Wap Push Test', 'High')

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  else
    response.data.to_json
  end
end

post '/send_mms' do

  response = @@att.sendMms(session['token'], '4252335893', 'image/jpeg', 'sencha.jpg', File.read('public/images/sencha.jpg'), "High", 'Subject Line')

  content_type :json

  if response.error?
    { :error => response.error }.to_json
  else
    response.data.to_json
  end
end

# This endpoint is used in order to show a 'Loading' page while the iframe is redirected
# to a new endpoint
get '/att_redirect' do
  erb :redirect
end

# This method passes whitelisted methods through to the Provider instance
post '/direct_router' do
  content_type :json

  request.body.rewind
  data = JSON.parse request.body.read

  response = {
    :type => "rpc",
    :tid => data['tid'],
    :action => data['action'],
    :method => data['method']
  }

  method_whitelist = %w(oauthUrl)
  requiring_access_whitelist = %w(deviceInfo deviceLocation sendSms sendSmsGsma smsStatus receiveSms mmsStatus)

  if data['action'] == 'Provider' and method_whitelist.include?(data['method'])
    response = response.merge(@@att.send("direct_#{data['method']}", data['data']))
  elsif data['action'] == 'Provider' and requiring_access_whitelist.include?(data['method'])
    if !session['token']
      response[:error] = 'Unauthorized request'
    else
      args = (data['data'] || []).unshift(session['token'])
      response = response.merge(@@att.send("direct_#{data['method']}", *args))
    end
  else
    response[:error] = 'Unrecognised method'
  end

  if response[:error]
    response = response.merge({
      :type => 'exception',
      :error => response[:error]
    })
  end

  response.to_json
end

get '/payments/deliver' do
  erb :callback
end

get '/payments/cancel' do
  erb :error
end

