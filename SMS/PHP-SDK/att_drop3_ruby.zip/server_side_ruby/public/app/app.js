/**
 * Registers the TeaCo application and dispatches to the index controller.
 */
Ext.regApplication({
    name: "TeaCo",

    launch: function() {
        Ext.dispatch({
            controller: 'index',
            action    : 'index'
        });

        // Initialize the Provider component.
        this.provider = new Sencha.Provider();
    }
});
