/**
 * Register the index controller and render the main application
 */
Ext.regController("index", {
    index: function() {
        this.render({
            // xtype: 'attMain'
            xtype: 'attKitchenSink'
        }, Ext.getBody());
    }
});