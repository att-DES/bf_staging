TeaCo.views.DeviceInfo = Ext.extend(Ext.Panel, {

    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        this.items = [{
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                title: 'Device Info',
                items: {
                    xtype: 'button',
                    text: 'Back',
                    handler: function() {
                        Ext.getCmp('viewport').setActiveItem(0, {type: 'slide', direction: 'right'});
                    }
                }
            }],
            layout: 'vbox',
            items: [
                { xtype: 'spacer' },
                {
                    xtype: 'button',
                    text: 'Device Info',

                    handler: self.deviceInfoHandler,
                    scope: self
                },
                { xtype: 'spacer' }
            ]
        }];

        TeaCo.views.DeviceInfo.superclass.initComponent.apply(this, arguments);

    },

    deviceInfoHandler: function() {

        var self = this;
        self.setLoading(true);

        TeaCo.provider.deviceInfo('4252334767', {
            success: function(response) {
                // On successful authorisation, proceed to the next page
                self.setLoading(false);
                Ext.Msg.alert('Device Info', JSON.stringify(response, null, '\t'));
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('Error', error);
            }
        });
    }
});

Ext.reg('attDeviceInfo', TeaCo.views.DeviceInfo);