TeaCo.views.SMS = Ext.extend(Ext.Panel, {

    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        this.items = [{
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                title: 'SMS',
                items: {
                    xtype: 'button',
                    text: 'Back',
                    handler: function() {
                        Ext.getCmp('viewport').setActiveItem(0, {type: 'slide', direction: 'right'});
                    }
                }
            }],
            layout: 'vbox',
            id: 'sms-buttons',
            items: [
                { xtype: 'spacer' },
                {
                    xtype: 'button',
                    text: 'Send SMS',
                    style: 'margin-bottom: 10px;',

                    handler: self.sendSmsHandler,
                    scope: self
                },
                {
                    xtype: 'button',
                    text: 'SMS Status',
                    id: 'sms-status-button',
                    style: 'margin-bottom: 10px;',

                    handler: this.smsStatusHandler,
                    scope: this,
                    disabled: true
                },
                {
                    xtype: 'button',
                    text: 'Send SMS GSMA',
                    style: 'margin-bottom: 10px;',

                    handler: self.sendSmsGsmaHandler,
                    scope: self
                },
                {
                    xtype: 'button',
                    text: 'Receive SMS',
                    style: 'margin-bottom: 10px;',

                    handler: self.receiveSmsHandler,
                    scope: self
                },
                { xtype: 'spacer' }
            ]
        }];

        TeaCo.views.SMS.superclass.initComponent.apply(this, arguments);

    },

    sendSmsHandler: function() {

        var self = this;

        // Show a 'loading' overlay mask
        self.setLoading(true);

        TeaCo.provider.sendSms('4252334767', 'Sencha Test SMS', {
            success: function(response) {
                // On successful authorisation, proceed to the next page
                self.setLoading(false);
                Ext.Msg.alert('Send SMS', JSON.stringify(response, null, '\t'));

                self.smsId = response.id;
                Ext.getCmp('sms-status-button').enable();
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('Error', error);
            }
        });
    },

    sendSmsGsmaHandler: function() {

        var self = this;
        self.setLoading(true);

        TeaCo.provider.sendSmsGsma('4252334767', 'Sencha Test SMS GSMA', {
            success: function(response) {
                // On successful authorisation, proceed to the next page
                self.setLoading(false);
                Ext.Msg.alert('Send SMS GSMA', JSON.stringify(response, null, '\t'));
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('SMS GSMA Error', error);
            }
        });
    },

    receiveSmsHandler: function() {

        var self = this;
        self.setLoading(true);

        TeaCo.provider.receiveSms({
            success: function(response) {
                self.setLoading(false);
                Ext.Msg.alert('Receive SMS Success', JSON.stringify(response, null, '\t'));
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('Receive SMS Error', JSON.stringify(error, null, '\t'));
            }
        })
    },

    smsStatusHandler: function() {

        var self = this;
        self.setLoading(true);

        TeaCo.provider.smsStatus(self.smsId, {
            success: function(response) {
                self.setLoading(false);
                Ext.Msg.alert('SMS Status Success', JSON.stringify(response, null, '\t'));
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('SMS Status Error', JSON.stringify(error, null, '\t'));
            }
        })
    }

});

Ext.reg('attSMS', TeaCo.views.SMS);