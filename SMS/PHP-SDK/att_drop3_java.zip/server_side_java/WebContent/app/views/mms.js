TeaCo.views.MMS = Ext.extend(Ext.Panel, {

    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        this.items = [{
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                title: 'MMS',
                items: {
                    xtype: 'button',
                    text: 'Back',
                    handler: function() {
                        Ext.getCmp('viewport').setActiveItem(0, {type: 'slide', direction: 'right'});
                    }
                }
            }],
            layout: 'vbox',
            items: [
                { xtype: 'spacer' },
                {
                    xtype: 'button',
                    text: 'Send MMS',
                    style: 'margin-bottom: 10px;',

                    handler: self.sendMmsHandler,
                    scope: self
                },
                {
                    xtype: 'button',
                    text: 'MMS Status',
                    id: 'mms-status-button',

                    handler: self.mmsStatusHandler,
                    disabled: true,
                    scope: self
                },
                { xtype: 'spacer' }
            ]
        }];

        TeaCo.views.MMS.superclass.initComponent.apply(this, arguments);

    },

    sendMmsHandler: function() {

        var self = this;
        self.setLoading(true);

        Ext.Ajax.request({
            url: '/send_mms',
            method: 'POST',
            success: function(resp){

                self.setLoading(false);
                var response = JSON.parse(resp.responseText);

                if (response.error) {
                    Ext.Msg.alert('MMS Send Success', JSON.stringify(response, null, '\t'))
                } else {
                    self.mmsId = response.id;
                    Ext.getCmp('mms-status-button').enable();
                    Ext.Msg.alert('MMS Send Error', JSON.stringify(response, null, '\t'))
                }
            }
        });
    },

    mmsStatusHandler: function() {

        var self = this;
        self.setLoading(true);

        TeaCo.provider.mmsStatus(self.mmsId, {
            success: function(response) {
                self.setLoading(false);
                Ext.Msg.alert('MMS Status Success', JSON.stringify(response, null, '\t'));
            },
            failure: function(error) {
                self.setLoading(false);
                Ext.Msg.alert('MMS Status Error', JSON.stringify(error, null, '\t'));
            }
        })
    }

});

Ext.reg('attMMS', TeaCo.views.MMS);