/**
 * The sample application consists of 3 pages: Login, Checkout and Thankyou.
 * The CSS for these pages is located in public/css/style.css
 * The pages use 2 background images instead of raw components, in public/images
 */
TeaCo.views.Main = Ext.extend(Ext.Panel, {
    id: 'viewport',
    layout: 'card',
    fullscreen: true,

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        // The first page is the Login screen
        this.items = [{
            cls: 'checkout login', // Set the CSS class of the container div
            layout: {
                type: 'vbox', // Child items should be laid our vertically
                align: 'start' // Align child items from the start fo the container
            },
            items: [
                {
                    xtype: 'button', // Create a 'Button' component
                    text: 'Login', // Make the text of the Button component 'Login'

                    // This function is run when the 'Login' button is pressed
                    handler: function() {

                        // Ask the user to login and authorize this application to process payments.
                        // This will pop up an AT&T login followed by an authorisation screen.
                        TeaCo.provider.authorizeApp('TL,DC,WAP,SMS,MMS,PAYMENT', {
                            success: function() {
                                // On successful authorisation, proceed to the next page
                                Ext.getCmp('viewport').layout.next();
                                TeaCo.provider.removeIframe();
                            },
                            failure: function() {
                                Ext.getCmp('viewport').layout.next();
                                TeaCo.provider.removeIframe();
                            }
                        });
                    }
                }
            ]
        }];

        // The second page is the Checkout page, which looks similar to the first page
        this.items.push({
            cls: 'checkout pay',
            layout: {
                type: 'vbox',
                align: 'start'
            },
            items: [
                {
                    xtype: 'button',
                    text: 'Make Payment',

                    // When the 'Make Payment' button is pressed...
                    handler: function() {

                        // Show a 'loading' overlay mask
                        self.setLoading(true);

                        // Server side request to process payment. Expects a 'result' object with
                        // either an error or an 'authorize payment' URL
                        Ext.Ajax.request({
                            url: '/payments',
                            method: 'POST',
                            success: function(response){
                                self.setLoading(false);

                                // Open authorize payment screen
                                TeaCo.provider.authorizePayment(response, {
                                    success: function() {
                                        Ext.Msg.alert('Payment Success', response.error);
                                        TeaCo.provider.removeIframe();
                                    },
                                    failure: function(response) {
                                        Ext.Msg.alert('Error', response.error);
                                        TeaCo.provider.removeIframe();
                                    }
                                });
                            }
                        });

                    }
                }
            ]
        });

        // The final page is the 'Thankyou' page, seen after a successful payment.
        this.items.push({
            cls: 'thankyou'
        });

        // This should always be called as the last item in the 'initComponent' method.
        // It ensures that superclass initComponent methods are also called
        TeaCo.views.Main.superclass.initComponent.apply(this, arguments);
    }
});

Ext.reg('attMain', TeaCo.views.Main);
