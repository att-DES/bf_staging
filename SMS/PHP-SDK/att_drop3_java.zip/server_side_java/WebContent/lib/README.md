# Sencha Provider component

## Overview

Sencha Touch is a mobile application framework for building rich, native like applications using Javascript
and CSS that run on any smartphone or tablet equipped with a webkit based browser.

Sencha Touch applications consist of a single HTML file - DOM elements and content are created dynamically 
with Javascript. As such, a Sencha Touch application only makes a single page request at startup. Any further 
server interactions happen via AJAX.

This presents a problem when dealing with services such as oAuth which typically require that the client 
browser is redirected to a third party website before being redirected back.

## IFrames

The Sencha Provider library deals with this problem by overlaying an iframe onto the content of the application. 
Once the user has finished interacting with the third party service they are redirected back to a page on the local 
web server. Since the domain of the iframe now matches that of the Sencha Touch application, the iframe has 
permission to call functions from its 'parent' frame.

This means that authorizations for oauth and payments can be completed without leaving the Sencha Touch application.

This is the underlying mechanism employed by the Sencha Provider component to allow interaction with the AT&T APIs
without the user having to leave the Sencha Touch application.

## Usage

The Sencha Provider component should can be initialized like this:

		var provider = new Sencha.Provider();
		
There are 3 APIs currently implemented:

### isAuthorized

This method is called to check if the user has an active access_token on the server. Usage:

		provider.isAuthorised('PAYMENT', {
			success: function() {
				alert('Already authenticated for Payments');
			},
			failure: function() {
				alert('Not already authenticated for Payments');
			}
		})
		
### authorizeApp

This method opens an authorization screen for users to give permission to the application
for a given scope. Usage:

		provider.authorizeApp('PAYMENT', {
			success: function() {
				alert('Application authenticated for Payments');
			},
			failure: function() {
				alert('Application not authenticated for Payments');
			}
		})

### authorizePayment

This method takes the response from a server side request to process a payment and presents
and authorization screen to the user. Usage:

		Ext.Ajax.request({
		    url: '/payments',
		    method: 'POST',
		    success: function(response){
		        provider.authorisePayment(response, {
		            success: function() {
		                alert('Payment successfully authorised');
		            },
		            failure: function() {
		                alert('Payment not authorised');
		            }
		        });
		    }
		});





