package com.sencha.example.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sencha.example.serviceprovider.att.ServiceProviderMMS;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * The servlet is called when the client application invoked the send a MMS
 * Message
 */
public class AttSendMMSServlet extends HttpServlet {
  public static final String telephone = "4252334767";

  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttSendMMSServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {
      JSONObject object = new JSONObject();

      File file = new File(getServletContext().getRealPath("images/sencha.jpg"));
      if (!file.exists()) {
        object.put(AttConstants.ERROR, "File not found " + file.getPath());
      }
      InputStream stream = new FileInputStream(file);
      String type = "image/jpeg";

      ServiceProviderMMS provider = new ServiceProviderMMS(AttConstants.HOST);
      TokenResponse resp = provider.sendMms((String) request.getSession().getAttribute(AttConstants.TOKEN), telephone,
          type, file.getName(), stream);

      if (!resp.hasError()) {
        resp.write(out);
      } else {
        String errorMessage = resp.optString(AttConstants.ERROR);
        if (errorMessage == null || errorMessage.length() == 0) {
          errorMessage = "MMS Error";
        }
        TokenResponse.getResponse(resp.optString(errorMessage)).write(out);
      }
    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      }
    } finally {
      out.flush();
      out.close();
    }
  }
}
