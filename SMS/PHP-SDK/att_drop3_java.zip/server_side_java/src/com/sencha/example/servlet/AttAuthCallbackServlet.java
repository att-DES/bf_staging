package com.sencha.example.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sencha.example.serviceprovider.att.ServiceProviderConstants;
import com.sencha.example.serviceprovider.att.ServiceProviderOauth;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * Once the user has logged in with their credentials, they get redirected to
 * this URL with a 'code' parameter. This is exchanged for an access token which
 * can be used in any future calls to the AT&T APIs
 */
public class AttAuthCallbackServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttAuthCallbackServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    ServiceProviderOauth provider = new ServiceProviderOauth(AttConstants.HOST, getClientID(), getClientSecret(),
        getHost(request));
    TokenResponse tokenres = provider.getToken(request.getParameter(AttConstants.CODE));
    if (!tokenres.hasError() && tokenres.getAccess_token().length() > 0) {
      request.getSession().setAttribute(ServiceProviderConstants.TOKEN, tokenres.getAccess_token());
      forward(AttConstants.CALLBACKHTML, request, response);
    } else {
      forward(AttConstants.ERRORHTML, request, response);
    }

  }

  private void forward(String aResponsePage, HttpServletRequest aRequest, HttpServletResponse aResponse)
      throws ServletException, IOException {
    RequestDispatcher dispatcher = aRequest.getRequestDispatcher(aResponsePage);
    dispatcher.forward(aRequest, aResponse);
  }

  private String getClientID() {
    return AttConstants.CLIENTIDSTRING;
  }

  private String getClientSecret() {
    return AttConstants.CLIENTSECRETSTRING;
  }

  private String getHost(HttpServletRequest request) {
    return "http://" + request.getServerName() + ":" + request.getServerPort();
  }
}
