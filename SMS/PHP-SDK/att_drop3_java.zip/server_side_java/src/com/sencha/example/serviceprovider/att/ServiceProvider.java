package com.sencha.example.serviceprovider.att;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.logging.Logger;

import org.json.JSONTokener;

public class ServiceProvider {
  private String host = "";
  private static Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);

  public ServiceProvider(String host) {
    this.host = host;
  }

  private String getHost() {
    return host;
  }

  /****
   * This method requests information about the device
   * 
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @return will return a JSONObject of the device information
   */
  public TokenResponse deviceInfo(String access_token, String tel) {
    return deviceInfo(getHost(), access_token, tel);
  }

  /****
   * This method requests information about the device
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @return will return a JSONObject of the device information
   */
  public static TokenResponse deviceInfo(String host, String access_token, String tel) {
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/devices/tel:" + tel + "/info?access_token=" + access_token);
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * This method requests information about the device
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param accuracy - The accuracy of the telephone
   * @return will return a JSONObject of the device location
   */
  public TokenResponse deviceLocation(String access_token, String tel, String accuracy){
    return deviceLocation(getHost(), access_token, tel, accuracy);
  }

  /****
   * This method requests information about the device
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param accuracy - The accuracy of the telephone
   * @return will return a JSONObject of the device location
   */
  public static TokenResponse deviceLocation(String host, String access_token, String tel, String accuracy) {
    TokenResponse theReturn = null;
    URL url;
    try {
      if (null == accuracy || accuracy.length() == 0) {
        accuracy = "1000";
      }
      LineLocator.log();
      url = new URL(host + "/1/devices/tel:" + tel + "/location?requestedAccuracy=" + accuracy + "&access_token="
          + access_token);
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * This method pushes a WAP Message
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param xml - The message to push
   * @return will return a JSONObject of the device location
   */
  public TokenResponse wapPush(String access_token, String tel, String xml) {
    return wapPush(getHost(), access_token, tel, xml);
  }

  /****
   * This method pushes a WAP Message
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param xml - The message to push
   * @return will return a JSONObject of the device location
   */
  public static TokenResponse wapPush(String host, String access_token, String tel, String xml) {
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/messages/outbox/wapPush?access_token=" + access_token);
      log.info("url: " + url.toString());
      String boundry = getBoundry();

      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setRequestMethod("POST");
      conn.setRequestProperty("content-type", "application/json");
      conn.setRequestProperty("accept", "application/json");
      conn.setRequestProperty("content-type",
          "multipart/form-data; type=\"application/json\"; start=\"<part0@sencha.com>\"; boundary=\"" + boundry + "\"");

      OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
      log.info("request: " + buildWAPMessage(boundry, tel, xml));
      wr.write(buildWAPMessage(boundry, tel, xml));
      wr.flush();
      wr.close();
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  private static String buildWAPMessage(String boundry, String telephone, String message) {
    StringBuffer theReturn = new StringBuffer("--").append(boundry).append("\n");
    theReturn.append("Content-Type: text/xml").append("\n");
    theReturn.append("Content-ID: <part0@sencha.com>").append("\n");
    theReturn.append("Content-Disposition: form-data; name=\"root-fields\"").append("\n");
    theReturn.append("\n");
    theReturn.append("<wapPushRequest>").append("\n");
    theReturn.append("<addresses>").append("\n");
    theReturn.append("<address>tel:").append(telephone).append("</address>").append("\n");
    theReturn.append("</addresses>").append("\n");
    theReturn.append("<subject>WAP</subject>").append("\n");
    theReturn.append("<priority>High</priority>").append("\n");
    theReturn.append("</wapPushRequest>").append("\n");
    theReturn.append("--").append(boundry).append("\n");
    theReturn.append("Content-Type: text/xml").append("\n");
    theReturn.append("Content-ID: <part2@sencha.com>").append("\n");
    theReturn.append("\n");
    theReturn.append("Content-Disposition: form-data; name=\"PushContent\"").append("\n");
    theReturn.append("Content-Type: text/vnd.wap.si").append("\n");
    theReturn.append("Content-Length: 12").append("\n");
    theReturn.append("X-Wap-Application-Id: x-wap-application:wml.ua").append("\n");
    theReturn.append("\n");
    theReturn.append(message);
    theReturn.append("\n");
    theReturn.append("--").append(boundry).append("--");
    return theReturn.toString();
  }

  private static String getBoundry() {
    return "----=_Part_0_1" + Math.round((Math.random() * 10000000)) + "." + new Date().getTime() * 1000;

  }
}
