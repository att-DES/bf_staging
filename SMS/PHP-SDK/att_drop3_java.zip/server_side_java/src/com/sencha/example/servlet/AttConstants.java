package com.sencha.example.servlet;


public class AttConstants {
  // Client ID from the AT&T Dev Connect portal.
  public static final String CLIENTIDSTRING = "615c78362f2ada9244d221fb19e0d8bb";

  // Client Secret from the AT&T Dev Connect portal.
  public static final String CLIENTSECRETSTRING = "6a8edc0a5cd928f9";
  
  // The shortcode is the SMS number used when sending and receiving SMS and MMS messages.
  public static final String SHORTCODE = "22527003";
  
  // Debug mode, should be set to false for productions environments
  public static final boolean DEBUG = true;
  
  // This is the main endpoint through which all API requests are made
//  public static final String HOST = "https://test-api.att.com";
  public static final String HOST = "https://api.att.com";

  public static final String SCOPE = "scope";
  public static final String CODE = "code";
  public static final String PAYMENTSCOPE = "PAYMENT";
  public static final String REDIRECT = "redirect";
  public static final String STARTHTML = "/index.html";
  public static final String REDIRECTHTML = "/redirect.html";
  public static final String ERRORHTML = "/error.jsp";
  public static final String CALLBACKHTML = "/callback.jsp";
  public static final String AUTHCHECKSTRING = "/auth/check";
  public static final String AUTHURLSTRING = "/auth/url";
  public static final String PAYMENTID = "payment_id";
  public static final String SUBSCRIPTIONID = "subscription_id";

  public static final String PROVIDER = "Provider";
  
  
  public static final String TID = "tid";
  public static final String TYPE = "type";
  public static final String ACTION = "action";
  public static final String METHOD = "method";
  public static final String TOKEN = "token";
  public static final String PAYMENTKEY = "paymentKey";
  public static final String ERROR = "error";
  public static final String ID = "id";
  public static final String SUCCESS = "success";
  public static final String TRXID = "trxID";

  public static final String PAYMENTERROR = "Payment Error";
  public static final String RPC = "rpc";

  
  
  }
