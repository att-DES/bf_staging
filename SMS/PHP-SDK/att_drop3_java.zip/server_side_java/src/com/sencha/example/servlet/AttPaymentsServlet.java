package com.sencha.example.servlet;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sencha.example.serviceprovider.att.PaymentMap;
import com.sencha.example.serviceprovider.att.ServiceProviderPayment;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * This endpoint demonstrates creating a new payment from the server side.
 * Typically, this call would be made as part of the checkout process, for
 * example when the customer clicks a 'Checkout' button from within the app.
 */
public class AttPaymentsServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttPaymentsServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {
      PaymentMap map = PaymentMap.createMap(getHost(request));
      map.put(PaymentMap.MERCHANTAPPLICATIONID, AttConstants.CLIENTIDSTRING);
      JSONObject object = new JSONObject();

      ServiceProviderPayment provider = new ServiceProviderPayment(AttConstants.HOST);
      TokenResponse resp = provider.createPayment((String) request.getSession().getAttribute(AttConstants.TOKEN), map);
//      JSONObject resp = ServiceProviderPayment.createPayment(map);
      if (resp.hasError() || !resp.getBoolean(AttConstants.SUCCESS)) {
        String errorMessage = resp.optString(AttConstants.ERROR);
        if (errorMessage == null || errorMessage.length() == 0) {
          errorMessage = AttConstants.PAYMENTERROR;
        }
        object.put(AttConstants.ERROR, errorMessage);
      } else {
        request.getSession().setAttribute(AttConstants.PAYMENTID, resp.getString(AttConstants.TRXID));
        object.put(AttConstants.REDIRECT, resp.get("redirectUrl"));
      }
      object.write(out);
    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      } finally {
        out.flush();
        out.close();
      }
    }
  }

  private String getHost(HttpServletRequest request) {
    return "http://" + request.getServerName() + ":" + request.getServerPort();
  }
}
