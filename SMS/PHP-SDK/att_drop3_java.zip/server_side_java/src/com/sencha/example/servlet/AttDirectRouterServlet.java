package com.sencha.example.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.sencha.example.serviceprovider.att.DirectServiceProvider;
import com.sencha.example.serviceprovider.att.ServiceProviderConstants;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * This method passes white listed methods through to the Provider instance
 */
public class AttDirectRouterServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  public static final String[] whiteList = {"oauthUrl"};

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttDirectRouterServlet() {
    super();
  }

  public void init() throws ServletException {
//    Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);
//    Handler h = new ConsoleHandler();
//    h.setLevel(Level.INFO);
//    log.addHandler(h);

    if(AttConstants.DEBUG){
      log("AT&T Provider initialized.");
      log("");
      log("API endpoint:  " + AttConstants.HOST);
      log("Client ID:     " + getClientID());
      log("Client Secret: " + getClientSecret());
      log("Shortcode:     " + AttConstants.SHORTCODE);
    }
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {

      JSONObject requestJSON = getData(request);
      JSONObject responseJSON = new JSONObject();

      String action = requestJSON.getString(AttConstants.ACTION);
      String method = requestJSON.getString(AttConstants.METHOD);

      boolean authorized = false;

      String token = (String) request.getSession().getAttribute(AttConstants.TOKEN);
      if (null != token && token.length() > 0) {
        authorized = true;
        requestJSON.put(ServiceProviderConstants.TOKEN, token);

      } else if (AttConstants.PROVIDER.equals(action) && inList(whiteList, method)) {
        authorized = true;
      } else {
        responseJSON.put(ServiceProviderConstants.ERROR, "Unauthorized request");
      }

      if (authorized) {
        requestJSON.put(ServiceProviderConstants.HOST, AttConstants.HOST);
        requestJSON.put(ServiceProviderConstants.CLIENTID, getClientID());
        requestJSON.put(ServiceProviderConstants.CALLBACK, getHost(request));
        requestJSON.put(ServiceProviderConstants.SHORTCODE, getShortCode());

        try {
          String modifiedMethod = ServiceProviderConstants.GET + method;
          Method foundMethod = DirectServiceProvider.class.getMethod(modifiedMethod.toLowerCase(), JSONObject.class);
          responseJSON = (JSONObject) foundMethod.invoke(DirectServiceProvider.class, requestJSON);
        } catch (NoSuchMethodException nsme) {
          responseJSON.put(ServiceProviderConstants.ERROR, "Unrecognised method");
        } catch (Exception e) {
          responseJSON.put(ServiceProviderConstants.ERROR, e.getMessage());
        }
        if (null == responseJSON.optString(AttConstants.TYPE)) {
          responseJSON.put("type", "exception");

        } else {
          responseJSON.put(AttConstants.TYPE, AttConstants.RPC);
        }
        responseJSON.put(AttConstants.TID, requestJSON.get(AttConstants.TID));
        responseJSON.put(AttConstants.ACTION, action);
        responseJSON.put(AttConstants.METHOD, method);
      }

      responseJSON.write(out);
    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      }
    } finally {
      out.flush();
      out.close();
    }
  }

  private String getClientID() {
    return AttConstants.CLIENTIDSTRING;
  }

  private String getClientSecret() {
    return AttConstants.CLIENTSECRETSTRING;
  }

  private String getShortCode() {
    return AttConstants.SHORTCODE;
  }

  private String getHost(HttpServletRequest request) {
    return "http://" + request.getServerName() + ":" + request.getServerPort();
  }

  private boolean inList(String[] stringArray, String name) {
    List<String> list = Arrays.asList(stringArray);
    Set<String> set = new HashSet<String>(list);
    return set.contains(name);
  }

  private JSONObject getData(HttpServletRequest request) throws JSONException {
    StringBuffer jb = new StringBuffer();
    String line = null;
    try {
      BufferedReader reader = request.getReader();
      while ((line = reader.readLine()) != null)
        jb.append(line);
    } catch (Exception e) {
      return new JSONObject().put(AttConstants.ERROR, e.getMessage());
    }
    return new JSONObject(jb.toString());
  }

}