package com.sencha.example.serviceprovider.att;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;

import org.json.JSONObject;
import org.json.JSONTokener;

public class ServiceProviderSMS {
  private String host = "";
  private String shortCode = "";
  private static Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);

  public ServiceProviderSMS(String host, String shortCode) {
    this.host = host;
    this.shortCode = shortCode;

  }

  private String getHost() {
    return host;
  }

  private String getShortCode() {
    return shortCode;
  }

  /****
   * This method requests information about the device
   * 
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param message - The message
   * @return the JSON result
   */
  public TokenResponse sendSms(String access_token, String tel, String message) {
    return sendSms(getHost(), access_token, tel, message);
  }

  /****
   * This method requests information about the device
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param message - The message
   * @return the JSON result
   */
  public static TokenResponse sendSms(String host, String access_token, String tel, String message) {
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/messages/outbox/sms?access_token=" + access_token);
      log.info("url: " + url.toString());

//      StringBuffer post = new StringBuffer();
//      post.append("address").append("=").append("tel:").append(tel).append("&");
//      post.append("message").append("=").append(message);
      JSONObject object = new JSONObject();
      object.put("address", "tel:" + tel);
      object.put("message", "message");

      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Content-Type", "application/json");
      conn.setRequestProperty("Accept", "application/json");
      
      OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
//      wr.write(post.toString());
      log.info("request: " + object.toString());
      object.write(wr);
      wr.flush();
      wr.close();

      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * This method requests information about the device
   * 
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param message - The message
   * @return the JSON result
   */
  public JSONObject sendSmsGsma(String access_token, String tel, String message) {
    return sendSmsGsma(getHost(), access_token, tel, message, getShortCode());
  }

  /****
   * This method requests information about the device
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param tel - The Telephone number of the user
   * @param message - The message
   * @param shortcode - The short code
   * @return the JSON result
   */
  public static TokenResponse sendSmsGsma(String host, String access_token, String tel, String message, String shortcode) {
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/gsma/1/smsmessaging/outbound/" + shortcode + "/requests?access_token=" + access_token);
      log.info("url: " + url.toString());

//      StringBuffer post = new StringBuffer();
//      post.append("address").append("=").append("tel:").append(tel).append("&");
//      post.append("message").append("=").append(message);
      JSONObject object = new JSONObject();
      object.put("address", "tel:" + tel);
      object.put("message", "message");
      
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Content-Type", "application/json");
      conn.setRequestProperty("Accept", "application/json");

      OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
      object.write(wr);
      //      wr.write(post.toString());
      wr.flush();
      wr.close();

      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * This method requests the Sms Status
   * 
   * @param access_token - The Token representing the logged in user
   * @param sms_id - The Sms Id
   * @return will return a JSONObject of the device information
   */
  public JSONObject smsStatus(String access_token, String sms_id){
    return smsStatus(getHost(), access_token, sms_id);
  }

  /****
   * This method requests the Sms Status
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param sms_id - The Sms Id
   * @return will return a JSONObject of the device information
   */
  public static TokenResponse smsStatus(String host, String access_token, String sms_id){
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/messages/outbox/sms/" + sms_id + "?access_token=" + access_token);
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * This method requests the Sms Status
   * 
   * @param token - The Token representing the logged in user
   * @param shortcode - The short code
   * @return will return a JSONObject of the device information
   */
  public JSONObject receiveSms(String token){
    return receiveSms(getHost(), token, getShortCode());
  }

  /****
   * This method requests the Sms Status
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param shortcode - The short code
   * @return will return a JSONObject of the device information
   */
  public static TokenResponse receiveSms(String host, String access_token, String shortcode){
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/messages/inbox/sms?access_token=" + access_token + "&registrationID=" + shortcode
          + "&format=json");
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
      
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }
}
