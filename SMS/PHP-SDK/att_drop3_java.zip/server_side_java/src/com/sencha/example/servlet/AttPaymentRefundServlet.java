package com.sencha.example.servlet;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sencha.example.serviceprovider.att.ServiceProviderPayment;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * Tries to refund a payment
 */
public class AttPaymentRefundServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttPaymentRefundServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {
      String scope = request.getParameter(AttConstants.SCOPE);
      if (null == scope || scope.length() == 0) {
        scope = AttConstants.PAYMENTSCOPE;
      }
      ServiceProviderPayment provider = new ServiceProviderPayment(AttConstants.HOST);
      provider.paymentRefund((String) request.getSession().getAttribute(AttConstants.TOKEN),
          (String) request.getSession().getAttribute(AttConstants.PAYMENTID), "Customer was not happy", 1).write(out);
    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      }
    } finally {
      out.flush();
      out.close();
    }
  }
}
