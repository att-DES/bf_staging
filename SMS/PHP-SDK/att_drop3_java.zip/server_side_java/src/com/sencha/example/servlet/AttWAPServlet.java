package com.sencha.example.servlet;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sencha.example.serviceprovider.att.ServiceProvider;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * The servlet is called when the client application invoked the send a WAP
 * Message
 */
public class AttWAPServlet extends HttpServlet {
  public static final String telephone = "4252334767";
  public static final String wapmessage = "<?xml version =\"1.0\"?>\n<!DOCTYPE si PUBLIC \"-//WAPFORUM//DTD SI 1.0//EN\" \"\">http://www.wapforum.org/DTD/si.dtd\">\n<si>\n<indication href=\"http://wap.uni-wise.com/hswap/zh_1/index.jsp?MF=N&Dir=23724\" si-id=\"1\">\n     CDMA Push test!!\n</indication>\n</si>";

  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttWAPServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {
      ServiceProvider provider = new ServiceProvider(AttConstants.HOST);
      TokenResponse resp = provider.wapPush((String) request.getSession().getAttribute(AttConstants.TOKEN), telephone,
          wapmessage);
      if (!resp.hasError()) {
        resp.write(out);
      } else {
        String errorMessage = resp.optString(AttConstants.ERROR);
        if (errorMessage == null || errorMessage.length() == 0) {
          errorMessage = "WAP Error";
        }
        TokenResponse.getResponse(resp.optString(errorMessage)).write(out);
      }
    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      }
    } finally {
      out.flush();
      out.close();
    }
  }
}
