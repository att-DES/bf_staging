package com.sencha.example.serviceprovider.att;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DirectServiceProvider {
  /****
   * Forwards request to ServiceProvider.getOAuthURL
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to getOAuthURL
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getoauthurl(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderOauth.oauthUrl(request.getString(ServiceProviderConstants.HOST), array.getString(0),
              request.getString(ServiceProviderConstants.CLIENTID),
              request.getString(ServiceProviderConstants.CALLBACK)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;

  }

  /****
   * Forwards request to ServiceProvider.getDeviceInfo
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to getDeviceInfo
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getdeviceinfo(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProvider.deviceInfo(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.getDeviceInfo
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to getDeviceInfo
   * @return will return a JSON Object with the device info
   */
  public static JSONObject ServiceProviderMMS(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProvider.deviceInfo(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.getDeviceLocation
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to getDeviceLocation
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getdevicelocation(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProvider.deviceLocation(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0),
              request.optString(ServiceProviderConstants.ACCURACY)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.sendSms
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to sendSms
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getsendsms(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderSMS.sendSms(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0), array.getString(1)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.sendSmsGsma
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to sendSmsGsma
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getsendsmsgsma(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderSMS.sendSmsGsma(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0), array.getString(1),
              request.getString(ServiceProviderConstants.SHORTCODE)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.getSmsStatus
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to getSmsStatus
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getsmsstatus(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderSMS.smsStatus(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.receiveSms
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to receiveSms
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getreceivesms(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderSMS.receiveSms(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), request.getString(ServiceProviderConstants.SHORTCODE)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }

  /****
   * Forwards request to ServiceProvider.mmsStatus
   * 
   * @param request - This method unpacks the JSONObject and forwards the request to mmsStatus
   * @return will return a JSON Object with the device info
   */
  public static JSONObject getmmsstatus(JSONObject request) {
    JSONObject theReturn = new JSONObject();
    try {
      JSONArray array = request.getJSONArray(ServiceProviderConstants.DATA);
      theReturn.put(
          ServiceProviderConstants.RESULT,
          ServiceProviderMMS.mmsStatus(request.getString(ServiceProviderConstants.HOST),
              request.getString(ServiceProviderConstants.TOKEN), array.getString(0)));
    } catch (Exception e) {
      try {
        theReturn.put(ServiceProviderConstants.ERROR, e.getMessage());
      } catch (JSONException e1) {
        System.out.println(e1.getMessage());
        e1.printStackTrace();
      }
    }
    return theReturn;
  }
}
