package com.sencha.example.servlet;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sencha.example.serviceprovider.att.ServiceProviderOauth;
import com.sencha.example.serviceprovider.att.TokenResponse;

/**
 * Generate the oauth redirect URL depending on the scope requested by the
 * client. The scope is specified as a parameter in the GET request and passed
 * to the provider library to obtain the appropriate Oauth URL
 */
public class AttAuthUrlServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public AttAuthUrlServlet() {
    super();
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Writer out = response.getWriter();
    try {
      String scope = request.getParameter(AttConstants.SCOPE);
      if (null == scope || scope.length() == 0) {
        scope = AttConstants.PAYMENTSCOPE;
      }
      JSONObject object = new JSONObject();
      ServiceProviderOauth provider = new ServiceProviderOauth(AttConstants.HOST, getClientID(), getClientSecret(),
          getHost(request));
      object.put(AttConstants.REDIRECT, provider.oauthUrl(scope));
      out.write(object.toString());

    } catch (Exception se) {
      try {
        TokenResponse.getResponse(se).write(out);
      } catch (Exception e) {
        log(se.getMessage());
        e.printStackTrace();
      }
    } finally {
      out.flush();
      out.close();
    }
  }

  private String getHost(HttpServletRequest request) {
    return "http://" + request.getServerName() + ":" + request.getServerPort();
  }

  private String getClientID() {
    return AttConstants.CLIENTIDSTRING;
  }

  private String getClientSecret() {
    return AttConstants.CLIENTSECRETSTRING;
  }
}
