package com.sencha.example.serviceprovider.att;

public class LineLocatorException extends Exception{
	/**
   * 
   */
  private static final long serialVersionUID = -3184280454311817539L;
  /**
	 * 
	 */

	public LineLocatorException(){
		super();
	}
	public LineLocatorException(String message){
		super(message);
	}
	public LineLocatorException(Exception excepiton){
      super(excepiton.getMessage());
  }
}
