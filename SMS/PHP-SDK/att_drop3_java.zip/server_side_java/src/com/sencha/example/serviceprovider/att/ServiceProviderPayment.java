package com.sencha.example.serviceprovider.att;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class ServiceProviderPayment {
  private static Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);
  public static final String SEPERATOR = "--";

  private String host = "";

  public ServiceProviderPayment(String host) {
    this.host = host;
  }

  private String getHost() {
    return host;
  }

  /***
   * 
   * @param map - PaymentMap that will contain all the needed information needed
   *          to process a payment
   * @return a JSONObject with the response from the payment
   */
  public TokenResponse createPayment(String access_token, PaymentMap map) {
    map.setToken(access_token);
    map.setHost(getHost());
    return createPayment(map);
  }

  /***
   * 
   * @param map - PaymentMap that will contain all the needed information needed
   *          to process a payment
   * @return a JSONObject with the response from the payment
   */
  public static TokenResponse createPayment(PaymentMap map) {
    TokenResponse theReturn = null;
    URL url;
    StringBuffer response = new StringBuffer();
    try {
      if (!map.validate()) {
        theReturn = TokenResponse.getResponse("PaymentMap is invalid");
      }
      LineLocator.log();
      url = new URL(map.getHost() + "/1/payments/transactions?access_token=" + map.getToken());
      log.info("url: " + url.toString());

      JSONObject object = new JSONObject();
      loadJSON(object, map);
      log.info("request: " + object.toString());

      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Content-Type", "application/json");
      conn.setRequestProperty("Accept", "application/json");
      OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
      // wr.write(object.toString());
      object.write(wr);
      wr.flush();
      wr.close();

      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * Gets the status of a payment
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param transaction_id - The transaction to get the status of
   * @return returns a JSONObject which contains the response from ATT
   */
  public TokenResponse paymentStatus(String access_token, String transaction_id) {
    return paymentStatus(getHost(), access_token, transaction_id);

  }

  /****
   * Gets the status of a payment
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param access_token - The Token representing the logged in user
   * @param transaction_id - The transaction to get the status of
   * @return returns a JSONObject which contains the response from ATT
   */
  public static TokenResponse paymentStatus(String host, String access_token, String transaction_id) {
    TokenResponse theReturn = null;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/payments/transactions/" + transaction_id + "?access_token=" + access_token);
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  /****
   * Refund a payment
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param token - The Token representing the logged in user
   * @param transaction_id - The transaction to refund
   * @param refundReason - The reason for the refund
   * @param refundCode - The refund Code
   * 
   * @return returns a JSONObject which contains the response from ATT
   */
  public TokenResponse paymentRefund(String token, String transaction_id, String refundReason, int refundCode) {
    return paymentRefund(getHost(), token, transaction_id, refundReason, refundCode);

  }

  /****
   * Refund a payment
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param token - The Token representing the logged in user
   * @param transaction_id - The transaction to refund
   * @param refundReason - The reason for the refund
   * @param refundCode - The refund Code
   * 
   * @return returns a JSONObject which contains the response from ATT
   */
  public static TokenResponse paymentRefund(String host, String token, String transaction_id, String refundReason,
      int refundCode) {
    TokenResponse theReturn = null;;
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/1/payments/transactions/" + transaction_id + "?access_token=" + token + "&action=refund");
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Content-Type", "application/json");
      conn.setRequestProperty("Accept", "application/json");
      OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
      JSONObject out = new JSONObject();
      out.put(ServiceProviderConstants.REFUNDREASON, refundReason);
      out.put(ServiceProviderConstants.REFUNDCODE, refundCode);
      out.write(wr);
      wr.flush();
      wr.close();

      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {

        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());
      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }

  private static void loadJSON(JSONObject object, Map<String, Object> map) throws JSONException {
    for (String key : map.keySet()) {
      object.put(key, map.get(key));
    }
  }
}
