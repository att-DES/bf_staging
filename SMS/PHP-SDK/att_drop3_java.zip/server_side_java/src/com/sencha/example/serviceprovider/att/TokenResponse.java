package com.sencha.example.serviceprovider.att;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class TokenResponse extends JSONObject {
  public static final String TOKEN = "access_token";
  public static final String REQUESTERROR1 = "RequestError";
  public static final String REQUESTERROR2 = "requestError";

  public static final String SERVICEEXCEPTION1 = "ServiceException";
  public static final String SERVICEEXCEPTION2 = "serviceException";
  public static final String SERVICEERROR = "serviceError";

  public static final String POLICYEXCEPTION1 = "PolicyException";
  public static final String POLICYEXCEPTION2 = "policyException";

  public static final String TEXT = "text";

  private TokenResponse() {

    super();
  }

  private TokenResponse(JSONTokener x) throws JSONException {
    super(x);

  }

  private TokenResponse(JSONObject x) throws JSONException {
    super(x);
  }

  /**
   * 
   * @return true of the token is not set
   */
  public boolean hasError() {
    return optString(ServiceProviderConstants.ERROR).length() > 0;
  }

  /**
   * @return extracts the access_token from the token
   */
  public String getAccess_token() {
    String theReturn = "";
    if (!hasError() && null != opt(TOKEN)) {
      theReturn = (String) opt(TOKEN);
    }
    return theReturn;
  }

  public static TokenResponse getResponse() {
    return getResponse("");
  }

  public static TokenResponse getResponse(Exception e) {
    return getResponse(e.getMessage());
  }

  public static TokenResponse getResponse(String errorMessage) {
    TokenResponse theReturn = new TokenResponse();
    try {
      theReturn.put(ServiceProviderConstants.ERROR, errorMessage);
    } catch (JSONException e) {
    }
    return theReturn;
  }

  public static TokenResponse getResponse(JSONTokener x) {
    TokenResponse theReturn = null;
    try {
      theReturn = processError(new TokenResponse(x));
    } catch (JSONException e) {
      theReturn = processError(x.toString());
    } catch (Exception e) {
      theReturn = getResponse(e.getMessage());
    }
    return theReturn;
  }

  public static TokenResponse getResponse(JSONObject x) {
    TokenResponse theReturn = null;
    try {
      theReturn = processError(new TokenResponse(x));
    } catch (JSONException e) {
      theReturn = processError(x.toString());
    } catch (Exception e) {
      theReturn = getResponse(e.getMessage());
    }
    return theReturn;
  }

  private static TokenResponse processError(TokenResponse token) {
    TokenResponse theReturn = token;
    JSONObject error = token.optJSONObject(REQUESTERROR1);
    if (null == error) {
      error = token.optJSONObject(REQUESTERROR2);
    }
    if (null != error) {
      JSONObject subError = error.optJSONObject(SERVICEEXCEPTION1);
      if (null == subError) {
        subError = error.optJSONObject(SERVICEEXCEPTION2);
      }
      if (null == subError) {
        subError = error.optJSONObject(POLICYEXCEPTION1);
      }
      if (null == subError) {
        subError = error.optJSONObject(POLICYEXCEPTION2);
      }
      if (null == subError) {
        subError = error.optJSONObject(SERVICEERROR);
      }
      if (null != subError) {
        theReturn = getResponse(subError.optString(TEXT));
      }
    }
    return theReturn;
  }

  private static TokenResponse processError(String root) {
    DocumentBuilder builder;
    try {
      builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
      return processError(builder.parse(root));

    } catch (Exception e) {
      return getResponse(root);
    }
  }

  private static TokenResponse processError(Document root) {
    return processError(root.getDocumentElement());
  }

  private static TokenResponse processError(Element root) {
    TokenResponse theReturn = new TokenResponse();
    NodeList nodeError = root.getElementsByTagName(REQUESTERROR1);
    Element error = null;
    if (nodeError.getLength() > 0) {
      error = (Element) nodeError.item(0);
    }
    nodeError = root.getElementsByTagName(REQUESTERROR2);
    if (nodeError.getLength() > 0) {
      error = (Element) nodeError.item(0);
    }
    if (null != error) {
      NodeList nodeSubError = error.getElementsByTagName(SERVICEEXCEPTION1);
      Element subError = null;
      if (nodeSubError.getLength() > 0) {
        subError = (Element) nodeSubError.item(0);
      }
      nodeSubError = error.getElementsByTagName(SERVICEEXCEPTION2);
      if (nodeSubError.getLength() > 0) {
        subError = (Element) nodeSubError.item(0);
      }
      nodeSubError = error.getElementsByTagName(POLICYEXCEPTION1);
      if (nodeSubError.getLength() > 0) {
        subError = (Element) nodeSubError.item(0);
      }
      nodeSubError = error.getElementsByTagName(POLICYEXCEPTION2);
      if (nodeSubError.getLength() > 0) {
        subError = (Element) nodeSubError.item(0);
      }
      nodeSubError = error.getElementsByTagName(SERVICEERROR);
      if (nodeSubError.getLength() > 0) {
        subError = (Element) nodeSubError.item(0);
      }

      if (null != subError) {
        nodeSubError = subError.getElementsByTagName(TEXT);
        if (nodeSubError.getLength() > 0) {
          Element text = (Element) nodeSubError.item(0);
          theReturn = TokenResponse.getResponse(text.getNodeValue());
        }
      }
    }
    return theReturn;
  }
}
