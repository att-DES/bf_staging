package com.sencha.example.serviceprovider.att;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LineLocator {
  private static Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);

  public static void log(){
    if(Level.FINER.equals(log.getLevel())){
      try{
        throw new LineLocatorException();
      }
      catch(LineLocatorException e){
        processStackTrace(e.getStackTrace());
      }
    }
  }
  private static void processStackTrace(StackTraceElement[] trace){
    log.info("Logging location:");
    for(int x=1; x < trace.length; x++){
      String value = trace[x].toString();
      if(value.startsWith("com.sencha")){
        log.info(value);
        //        System.out.println(value);
      }
      else{
        break;
      }
    }
  }
}
