package com.sencha.example.serviceprovider.att;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;

import org.json.JSONTokener;

public class ServiceProviderOauth {
  private String host = "";
  private String client_id = "";
  private String client_secret = "";
  private String callback = "";
  private static Logger log = Logger.getLogger(ServiceProviderConstants.SERVICEPROVIDERLOGGER);

  /******
   * 
   * @param host - The domain name (or ip address) and port the request is
   * @param client_id The clients id. This may look something like
   *          c4c9084c6e9cb6ca01886a15e7dfd486
   * @param client_secret
   * @param callback The URL to callback to when the user has logged in. Example
   *          http://localhost:8080
   * 
   */
  public ServiceProviderOauth(String host, String client_id, String client_secret, String callback) {
    this.host = host;
    this.client_id = client_id;
    this.client_secret = client_secret;
    this.callback = callback;

  }

  private String getHost() {
    return host;
  }

  private String getClientID() {
    return client_id;
  }

  private String getClientSecret() {
    return client_secret;
  }

  private String getCallback() {
    return callback;
  }

  /****
   * Generates a Authorization URL to login the user
   * 
   * @param scope - The scope that will be embedded in the request. Example
   *          PAYMENT
   * @return will return a url where the user can log in. Example
   *         https://beta-api.att.com/oauth/authorize?scope=PAYMENT&client_id=
   *         c4c9084c6e9cb6ca01886a15e7dfd486
   *         &type=web_server&redirect_uri=http://localhost:8080/auth/callback
   */
  public String oauthUrl(String scope) {
    return oauthUrl(getHost(), scope, getClientID(), getCallback());
  }

  /****
   * Generates a Authorization URL to login the user
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param scope - The scope that will be embedded in the request. Example
   *          PAYMENT
   * @param client_id - The clients id. This may look something like
   *          c4c9084c6e9cb6ca01886a15e7dfd486
   * @param callback - The URL to callback to when the user has logged in.
   *          Example http://localhost:8080
   * @return will return a url where the user can log in. Example
   *         https://beta-api.att.com/oauth/authorize?scope=PAYMENT&client_id=
   *         c4c9084c6e9cb6ca01886a15e7dfd486
   *         &type=web_server&redirect_uri=http://localhost:8080/auth/callback
   */
  public static String oauthUrl(String host, String scope, String client_id, String callback) {
    return host + "/oauth/authorize?scope=" + scope + "&client_id=" + client_id + "&type=web_server&redirect_uri="
        + callback + "/auth/callback";
  }

  /****
   * 
   * @param clientID - The clients id. This may look something like
   *          c4c9084c6e9cb6ca01886a15e7dfd486
   * @param clientSecret - The clients secret. This may look something like
   *          a0725b93040cfe0e
   * @param code - This is the one time code returned when the user has logged
   *          in.
   * @return returns a TokenResponse which should concern a access_token
   * @throws ServiceProviderException - throws if any problems occur
   */
  public TokenResponse getToken(String code) {
    return getToken(getHost(), getClientID(), getClientSecret(), code);

  }

  /****
   * 
   * @param host - The domain name (or ip address) and port the request is
   *          submitted to. Example https://beta-api.att.com
   * @param client_id - The clients id. This may look something like
   *          c4c9084c6e9cb6ca01886a15e7dfd486
   * @param client_secret - The clients secret. This may look something like
   *          a0725b93040cfe0e
   * @param code - This is the one time code returned when the user has logged
   *          in.
   * @return returns a TokenResponse which should concern a access_token
   * @throws ServiceProviderException - throws if any problems occur
   */
  public static TokenResponse getToken(String host, String client_id, String client_secret, String code) {
    TokenResponse theReturn = TokenResponse.getResponse();
    URL url;
    try {
      LineLocator.log();
      url = new URL(host + "/oauth/access_token?client_id=" + client_id + "&client_secret=" + client_secret + "&code="
          + code);
      log.info("url: " + url.toString());
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setDoInput(true);
      StringBuffer response = new StringBuffer();
      if (conn.getResponseCode() < 400) {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      } else {
        BufferedReader is = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        String str;
        while (null != ((str = is.readLine()))) {
          response.append(str);
        }
        is.close();
      }
      log.info("response: " + response.toString());

      theReturn = TokenResponse.getResponse(new JSONTokener(response.toString()));
    } catch (Exception e) {
      theReturn = TokenResponse.getResponse(e.getMessage());
    }
    return theReturn;
  }
}
