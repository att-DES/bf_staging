package com.sencha.example.serviceprovider.att;

import java.util.Date;
import java.util.HashMap;

public class PaymentMap extends HashMap<String, Object> {
	public static final String TRANSACTIONID = "transaction_id";
	public static final String PRODUCTID = "product_id";
	public static final String AMOUNT = "amount";
	public static final String CATEGORY = "category";
	public static final String CHANNEL = "channel";
	public static final String CURRENCY = "currency";
	public static final String DESCRIPTION = "description";
	public static final String EXTERNALMERCANTTRANSACTIONID = "externalMerchantTransactionID";
	public static final String MERCHANTAPPLICATIONID = "merchantApplicationID";
	public static final String MERCHANTCANCELREDIRECT = "merchantCancelRedirectUrl";
	public static final String MERCHANTFULFILLMENTREDIRECTURL = "merchantFulfillmentRedirectUrl";
	public static final String MERCHANTPRODUCTID = "merchantProductID";
	public static final String PURCHASEONNOACTIVESUBCRIPTION = "purchaseOnNoActiveSubscription";
	public static final String TRANSACTIONSTATUSCALLBACKURL = "transactionStatusCallbackUrl";
	public static final String AUTOCOMMIT = "autoCommit";
	
	public static final String SUBSCRIPTIONRECURRENINGNUMBER = "subscriptionRecurringNumber";
    public static final String SUBSCRIPTIONRECURRINGPERIOD = "subscriptionRecurringPeriod";
    public static final String SUBSCRIPTIONRECURRINGPERIODAMOUNT = "subscriptionRecurringPeriodAmount";
    public static final String MERCHANTSUBSCRIPITONIDLIST = "merchantSubscriptionIdList";

	private static final long serialVersionUID = -6958215217152714252L;
	private String host = "";

	private String callback = "";
	private String token = "";

	/**
	 * @return the host string
	 */

	public String getHost() {
		return host;
	}

	/**
	 * @param host
	 *            - The domain name (or ip address) and port the request is
	 *            submitted to. Example https://beta-api.att.com
	 */

	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * 
	 * @return returns the token.
	 */

	public String getToken() {
		return token;
	}

	/**
	 * 
	 * @param token
	 *            used to identified the users
	 */

	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * 
	 * @return The URL to callback to when the user has logged in. Example
	 *         http://localhost:8080
	 */

	public String getCallback() {
		return callback;
	}

	/**
	 * 
	 * @param callback
	 *            - The URL to callback to when the user has logged in. Example
	 *            http://localhost:8080
	 */

	public void setCallback(String callback) {
		this.callback = callback;
	}

	/***
     * 
     * @param host
     *            - The domain name (or ip address) and port the request is
     *            submitted to. Example https://beta-api.att.com
     * @param callback
     *            - The URL to callback to when the user has logged in. Example
     *            http://localhost:8080
     * @param token
     *            - used to identified the users
     */

    private PaymentMap(String callback) {
        setCallback(callback);
    }

    
	/***
	 * 
	 * @param host
	 *            - The domain name (or ip address) and port the request is
	 *            submitted to. Example https://beta-api.att.com
	 * @param callback
	 *            - The URL to callback to when the user has logged in. Example
	 *            http://localhost:8080
	 * @param token
	 *            - used to identified the users
	 */

	private PaymentMap(String host, String callback, String token) {
		setHost(host);
		setCallback(callback);
		setToken(token);
	}

	/**
	 * This method will set up a Payment Map will all the required elements.
	 * @param callback
	 */

	private void init(String callback) {
		put(AMOUNT, 2.22);
		put(CATEGORY, 1);
		put(CHANNEL, "MOBILE_WEB");
		put(CURRENCY, "USD");
		put(DESCRIPTION, "Sencha Description");
		put(EXTERNALMERCANTTRANSACTIONID, getID("SenchaTransId"));
		put(MERCHANTAPPLICATIONID, "Payment876875");
		put(MERCHANTCANCELREDIRECT, callback + "/payments/cancel");
		put(MERCHANTFULFILLMENTREDIRECTURL, callback + "/payments/deliver");
		put(MERCHANTPRODUCTID, "SenchaProduct60214");
		put(PURCHASEONNOACTIVESUBCRIPTION, false);
		put(TRANSACTIONSTATUSCALLBACKURL, callback + "/payments/notify");
		put(AUTOCOMMIT, true);
	}
	/**
     * This method will set up a Payment Map will all the required elements.
     * @param callback
     */

    private void initSubscription(String callback) {
        init(callback);
        put(SUBSCRIPTIONRECURRENINGNUMBER, "99999");
        put(SUBSCRIPTIONRECURRINGPERIOD, "MONTHLY");
        put(SUBSCRIPTIONRECURRINGPERIODAMOUNT, "1");
        put(MERCHANTSUBSCRIPITONIDLIST, new Date().getTime());
    }

	private String getID(String id){
	  StringBuffer theReturn = new StringBuffer(id);
	  for(int x=0; x < 13; x++){
	    theReturn.append(Math.round((10 * Math.random())));
	  }
	  
	  return theReturn.toString();
	}
	/***
	 * This is the constructor that will return the PaymentMap without any elements
	 * 
	 * @param host
	 *            - The domain name (or ip address) and port the request is
	 *            submitted to. Example https://beta-api.att.com
	 * @param callback
	 *            - The URL to callback to when the user has logged in. Example
	 *            http://localhost:8080
	 * @param token
	 *            - used to identified the users
	 */

	public static PaymentMap createEmptyMap(String host, String callback,
			String token) {
		return new PaymentMap(host, callback, token);
	}
	/***
     * This is the constructor that will return the PaymentMap that has been initialized using the init() method.
     * 
     * @param host
     *            - The domain name (or ip address) and port the request is
     *            submitted to. Example https://beta-api.att.com
     * @param callback
     *            - The URL to callback to when the user has logged in. Example
     *            http://localhost:8080
     * @param token
     *            - used to identified the users
     */
    public static PaymentMap createMap(String callback) {
        PaymentMap map = new PaymentMap(callback);
        map.init(callback);
        return map;
    }
    
	/***
	 * This is the constructor that will return the PaymentMap that has been initialized using the init() method.
	 * 
	 * @param host
	 *            - The domain name (or ip address) and port the request is
	 *            submitted to. Example https://beta-api.att.com
	 * @param callback
	 *            - The URL to callback to when the user has logged in. Example
	 *            http://localhost:8080
	 * @param token
	 *            - used to identified the users
	 */
	public static PaymentMap createMap(String host, String callback,
			String token) {
		PaymentMap map = new PaymentMap(host, callback, token);
		map.init(callback);
		return map;
	}
	/***
     * This is the constructor that will return the PaymentMap that has been initialized using the initSubscription() method.  Designed to be used for subscriptions
     * 
     * @param host
     *            - The domain name (or ip address) and port the request is
     *            submitted to. Example https://beta-api.att.com
     * @param callback
     *            - The URL to callback to when the user has logged in. Example
     *            http://localhost:8080
     * @param token
     *            - used to identified the users
     */
    public static PaymentMap createSubscriptionMap(String callback) {
        PaymentMap map = new PaymentMap(callback);
        map.initSubscription(callback);
        return map;
    }
    
	/***
     * This is the constructor that will return the PaymentMap that has been initialized using the initSubscription() method.  Designed to be used for subscriptions
     * 
     * @param host
     *            - The domain name (or ip address) and port the request is
     *            submitted to. Example https://beta-api.att.com
     * @param callback
     *            - The URL to callback to when the user has logged in. Example
     *            http://localhost:8080
     * @param token
     *            - used to identified the users
     */
    public static PaymentMap createSubscriptionMap(String host, String callback,
            String token) {
        PaymentMap map = new PaymentMap(host, callback, token);
        map.initSubscription(callback);
        return map;
    }

	/**
	 * 
	 * @return true if all of the contained items are included
	 */

	public boolean validate() {
		return (
		        containsKey(AMOUNT) 
				&& containsKey(CATEGORY)
				&& containsKey(CHANNEL) 
				&& containsKey(CURRENCY)
				&& containsKey(DESCRIPTION)
				&& containsKey(EXTERNALMERCANTTRANSACTIONID)
				&& containsKey(MERCHANTAPPLICATIONID)
				&& containsKey(MERCHANTCANCELREDIRECT)
				&& containsKey(MERCHANTFULFILLMENTREDIRECTURL)
				&& containsKey(MERCHANTPRODUCTID)
				&& containsKey(PURCHASEONNOACTIVESUBCRIPTION)
				&& containsKey(TRANSACTIONSTATUSCALLBACKURL) 
				&& containsKey(AUTOCOMMIT));
	}
}