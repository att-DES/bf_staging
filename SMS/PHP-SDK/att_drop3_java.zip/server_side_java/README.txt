# AT&T HTML5 API libraries

## Introduction

The AT&T REST APIs allows application developers to leverage powerful functionality in their apps such
as user authentication and payment processing.

The Sencha Provider library exposes these APIs for HTML 5 developers with a lightweight wrapper
consisting of a client and server component.

The server component is a standalone library handling the interaction with the AT&T API and will be
available in multiple flavors including Ruby, PHP and Java. It is designed to be used in conjunction with
a Servlet Container such as Apache Tomcat

The client component interacts with the server to provide a seamless, cross platform experience for the 
application developer.

## Components

This project consists of 4 parts:

 - A Java ServiceProvider wrapper for AT&T's HTML5 APIs (in com.sencha.example.ServiceProvider)
 - A sample Java Servlet providing endpoints required for using the AT&T APIs (com.sencha.example.AttServlet)
 - A sample Sencha Touch application demonstrating the Login and Payment APIs from start to finish (in WebContent)
 - A javascript component for interacting with the server side (in ./WebContent/lib/SenchaProvider.js)

## Dependencies

 - JavaEE 
 - JSON library (included)

## Building

	1.  Using Ant and the command line.  Navigate to build.xml file in the Root of the Att Sample project.  
	2.  Edit the build.xml and change the j2eeJar property to be the location of your J2EE jar file
	3.  Type ant on the command line.  This should generate an att.war file.

## Starting the example

1.  Place the att.war in the J2EE container (Tomcat) webapps directory
2.  You may need to expand the att.war directory and rename it to ROOT in the case of Tomcat
3.  Start your J2EE server (This may be Tomcat)
	
4. Navigate to http://your-ip-address:8080 from your webkit based browser or mobile device

## Further information

./WebContent/lib/README.md - the Readme for the client side component
./lib/sencha/README.txt - the Readme for the server side component

http://docs.sencha.com/touch - Sencha Touch documentation
