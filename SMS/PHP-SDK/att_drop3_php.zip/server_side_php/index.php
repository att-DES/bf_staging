<?php
session_start();
function __autoload($class) {
  require_once("./lib/sencha/service_provider/$class.php");
}

# The root URL starts off the Sencha Touch application. On the desktop, any Webkit browser
# will work, such as Google Chrome or Apple Safari. It's best to use desktop browsers
# when developing and debugging your application due to the superior developer tools such
# as the Web Inspector.

# Set up the ATT library with the Client application ID and secret. These will have been
# given to you when you registered your application on the AT&T developer site.
$provider = ProviderFactory::init(array(
  "provider" => "att",

  # Client ID and Secret from the AT&T Dev Connect portal.
  //"client_id" => "b50268e79553c93934cd035ff8a33000", # R1 Test new sandbox
  "client_id" => "b6a2db7814b2ad3310a672e06bc8254f", # R1 Test new sandbox
  //"client_secret" => "f4e4e48ff7f987c7",
  "client_secret" => "a866468654884e40",

  # This is the main endpoint through which all API requests are made
  //"host" => "https://test-api.att.com",
  "host" => "https://api.att.com",

  # The address of the locally running server. This is used when a callback URL is
  # required when making a request to the AT&T APIs.
  "local_server" => "http://localhost.org:4567",

  # The shortcode is the SMS number used when sending and receiving SMS and MMS messages.
  "shortcode" => "22827009"

  # AT&T Username, Password and Cell number for use in testing
  # qaydmitris test1ng 4252334767
  # qaysdktest6 welcome1 4252334767
  # jaisonw@isoftstone.com welcome1 4252335893
));

# serialize and add to session array so other scripts have access to it
$_SESSION['provider'] = serialize($provider);

header("Location: /views");
?>
