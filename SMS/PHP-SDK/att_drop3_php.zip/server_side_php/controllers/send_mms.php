<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {
  $provider = unserialize($_SESSION['provider']);
  $encoded_file = $provider->base64Encode("../public/images/sencha.jpg");
  $response = $provider->sendMms($_SESSION['token'], "8306600565", "image/jpeg", "sencha.jpg", $encoded_file);
  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } else {
    echo json_encode($response->data());
  }
}
?>
