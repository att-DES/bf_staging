<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

if (isset($_GET['url'])) {
  # Generate the oauth redirect URL depending on the scope requested by the client.
  # The scope is specified as a parameter in the GET request and passed to the provider
  # library to obtain the appropriate Oauth URL
  $provider = unserialize($_SESSION['provider']);
  $url = $provider->oauthUrl($_GET['scope']);
  echo "{\"redirect\": " . json_encode($url) . "}";
}

if (isset($_GET['check'])) {
  # Return a json object with either 'true' or 'false' depending on whether an
  # access_token has been set. This indicates whether the user is logged in.
  $bool = isset($_SESSION['token']) ? true : false;
  echo "{\"authorized\": " . json_encode($bool) . "}";
}
?>
