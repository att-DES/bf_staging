<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {
  $provider = unserialize($_SESSION['provider']);
  $response = $provider->wapPush($_SESSION['token'], "8306600565",
    '<?xml version ="1.0"?>' .  "\n" .
    '<!DOCTYPE si PUBLIC "-//WAPFORUM//DTD SI 1.0//EN" "">http://www.wapforum.org/DTD/si.dtd">' .  "\n" .
    '<si>' .  "\n" .
    '   <indication href="http://wap.uni-wise.com/hswap/zh_1/index.jsp?MF=N&Dir=23724" si-id="1">' .  "\n" .
    '     CDMA Push test!!' .  "\n" .
    '   </indication>' .  "\n" .
    '</si>'
  );

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } else {
    echo json_encode($response->data());
  }
}
?>
