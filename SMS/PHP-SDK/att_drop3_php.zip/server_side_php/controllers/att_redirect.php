<?php
# This endpoint is used in order to show a 'Loading' page while the iframe is redirected
# to a new endpoint
if ($_SERVER['REQUEST_METHOD'] === "GET") {
  header("Location: /views/redirect.php");
}
?>
