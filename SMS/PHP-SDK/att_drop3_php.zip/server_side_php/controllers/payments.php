<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

# This endpoint demonstrates creating a new payment from the server side. Typically, this
# call would be made as part of the checkout process, for example when the customer clicks
# a 'Checkout' button from within the app.

#Payments
if (isset($_POST['action']) && $_POST['action'] == "createPayment") {
  #create payment
  $provider = unserialize($_SESSION['provider']);
  $response = $provider->createPayment($_SESSION['token'], array(
    "product_id" => "SenchaProduct60214",
    "amount" => 1.29,
    "description" => "Sencha Description",
    "transaction_id" => "SenchaTransId" . time()
  ));

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } elseif ($response->data()->redirectUrl == "") {
    echo "{\"error\": \"Payment Error\"}";
  } else {
    $_SESSION['payment_id'] = $response->data()->trxID;
    echo "{\"redirect\": " . json_encode($response->data()->redirectUrl) . "}";
  }
}

if ($_POST['refund']) {
  $provider = unserialize($_SESSION['provider']);
  $response = $provider->paymentRefund($_SESSION['token'], array(
    "transaction_id" => $_SESSION['payment_id'],
    "reason" => "Customer was not happy",
    "code" => 1
  ));

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } else {
    echo json_encode($response->data());
  }
}

if (isset($_GET['action']) && $_GET['action'] == "paymentStatus") {
  #get payment status
  $provider = unserialize($_SESSION['provider']);
  $response = $provider->paymentStatus($_SESSION['token'], $_SESSION['payment_id']);

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } else {
    echo json_encode($response->data());
  }
}

if (isset($_GET['deliver'])) {
  header("Location: /views/callback.php");
}

if (isset($_GET['cancel'])) {
  header("Location: /views/error.php");
}

#Subscriptions
if (isset($_POST['action']) && $_POST['action'] == "createSubscription") {
  #create subscription
  $provider = unserialize($_SESSION["provider"]);
  $response = $provider->createSubscription($_SESSION["token"], array(
    "product_id" => "SenchaProduct60214",
    "amount" => 1.29,
    "description" => "Sencha Description",
    "transaction_id" => "SenchaTransId" . time(),
    "recurrences" => 99999,
    "recurrence_period" => "MONTHLY",
    "recurrence_interval" => 1,
    "subscription_id" => "SEN" . time()
  ));

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } elseif ($response->data()->redirectUrl == "") {
    echo "{\"error\": \"Subscription Error\"}";
  } else {
    $_SESSION['subscription_id'] = $response->data()->trxID;
    echo "{\"redirect\": " . json_encode($response->data()->redirectUrl) . "}";
  }
}

if (isset($_GET['action']) && $_GET['action'] == "subscriptionStatus") {
  #subscription status
  $provider = unserialize($_SESSION["provider"]);
  $response = $provider->subscriptionStatus($_SESSION["token"], $_SESSION['subscription_id']);

  if ($response->isError()) {
    echo "{\"error\": " . json_encode($response->error()) . "}";
  } else {
    echo json_encode($response->data());
  }
}?>
