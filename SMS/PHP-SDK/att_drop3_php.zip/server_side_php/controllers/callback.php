<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

if ($_GET['code']) {
  # Once the user has logged in with their credentials, they get redirected to this URL
  # with a 'code' parameter. This is exchanged for an access token which can be used in any
  # future calls to the AT&T APIs
  $code = trim($_GET['code']);

  # get the object
  $provider = unserialize($_SESSION['provider']);

  if (!$code) {
    # if there is no code then redirect to an HTML template located in ./views/error.php, passing local variables which can be accessed from inside the template
    header("Location: /views/error.php?error='No auth code'"); //FIX!

  } else {
    $response = $provider->getToken($code);

    if ($response->isError()) {
      header("Location: /views/error.php?error='" . $response->error() . "'");

    } else {
      # Store the auth token in the session for use in future API calls
      $_SESSION['token'] = $response->data()->access_token;

      # Render the `callback` template in ./views/callback.erb
      # This template will attempt to run the `successCallback` function
      # in the parent iframe.
      header("Location: /views/callback.php");
    }
  }
}
?>
