<?php
session_start();
function __autoload($class) {
  require_once("../lib/sencha/service_provider/$class.php");
}

if ($_SERVER['REQUEST_METHOD'] === "POST") {

  # access the object created in index.php
  $provider = unserialize($_SESSION['provider']);

  # get raw post data
  $data = json_decode(trim(file_get_contents("php://input")));

  $response = (object) array(
    "type" => "rpc",
    "tid" => $data->tid,
    "action" => $data->action,
    "method" => $data->method
  );

  $method_whitelist = array("oauthUrl");
  $requiring_access_whitelist = array("deviceInfo", "deviceLocation", "sendSms", "sendSmsGsma", "smsStatus", "receiveSms", "mmsStatus");

  # This passes whitelisted methods through to the Provider instance
  if ($data->action === "Provider" && in_array($data->method, $method_whitelist)) {
    $response = (object) array_merge((array) $response, (array) $provider->{"direct_" . $data->method}($data->data[0]));

  } elseif ($data->action === "Provider" && in_array($data->method, $requiring_access_whitelist)) {
    if (!$_SESSION['token']) {
      $response->error = "Unauthorized request";

    } else {
      if (!$data->data) { //some methods like receiveSms have a null value for $data->data;
        $data->data = array();
      }

      # always push the token to the front of the data array
      array_unshift($data->data, $_SESSION['token']);

      # the router makes dynamic function calls with a variable number of arguments
      $response = (object) array_merge((array) $response, (array) call_user_func_array(array($provider, "direct_" . $data->method), $data->data));
    }

  } else {
    $response->error = "Unrecognised method";
  }

  if ($response->error) {
    $response = (object) array_merge((array) $response, array("type" => "exception", "error" => $response->error));
  }

  echo json_encode($response);
}
?>
