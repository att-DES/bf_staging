TeaCo.views.ApiList = Ext.extend(Ext.Panel, {
    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        Ext.regModel('Section', { fields: ['section', 'page'] });

        var store = new Ext.data.JsonStore({
            model: 'Section',
            data: [
                { section: 'Device Info', page: 'attDeviceInfo' },
                { section: 'Device Location', page: 'attDeviceLocation' },
                { section: 'Payments', page: 'attPayments' },
                { section: 'SMS', page: 'attSMS' },
                { section: 'MMS', page: 'attMMS' },
                { section: 'WAP', page: 'attWAP' }
            ]
        });

        this.items = {
            dockedItems: [{ xtype: 'toolbar', dock: 'top', title: 'AT&T APIs' }],
            xtype: 'panel',
            layout: 'fit',
            items: {
                xtype: 'list',
                id: 'api-list',
                itemTpl: '{section}',
                store: store,
                listeners: {
                    itemtap: function(dataView, idx) {
                        var xtype = dataView.getStore().getAt(idx).get('page');
                        var viewport = Ext.getCmp('viewport');
                        viewport.add({xtype: xtype});
                        viewport.setActiveItem(1)
                    }
                }
            }

        };

        // This should always be called as the last item in the 'initComponent' method.
        // It ensures that superclass initComponent methods are also called
        TeaCo.views.ApiList.superclass.initComponent.apply(this, arguments);
    }
});

Ext.reg('attApiList', TeaCo.views.ApiList);
