TeaCo.views.Payments = Ext.extend(Ext.Panel, {

    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        this.items = [{
            id: 'payment-buttons',
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                title: 'Payments',
                items: {
                    xtype: 'button',
                    text: 'Back',
                    handler: function() {
                        Ext.getCmp('viewport').setActiveItem(0, {type: 'slide', direction: 'right'});
                    }
                }
            }],
            layout: 'vbox',
            items: [
                { xtype: 'spacer' },
                {
                    xtype: 'button',
                    text: 'New Payment',
                    style: 'margin-bottom: 10px;',

                    handler: self.newPaymentHandler,
                    scope: self
                },
                {
                    id: 'payment-status-button',
                    xtype: 'button',
                    text: 'Payment Status',
                    style: 'margin-bottom: 10px;',
                    disabled: true,

                    handler: self.paymentStatusHandler,
                    scope: self
                },
                {
                    id: 'payment-refund-button',
                    xtype: 'button',
                    text: 'Payment Refund',
                    style: 'margin-bottom: 10px;',
                    disabled: true,

                    handler: self.paymentRefundHandler,
                    scope: self
                },
                {
                    xtype: 'button',
                    text: 'New Subscription',
                    id: 'new-subscription-button',
                    style: 'margin-bottom: 10px;',

                    handler: self.newSubscriptionHandler,
                    scope: self
                },
                {
                    xtype: 'button',
                    text: 'Subscription Status',
                    id: 'subscription-status-button',
                    style: 'margin-bottom: 10px;',
                    disabled: true,

                    handler: self.subscriptionStatusHandler,
                    scope: self
                },
                { xtype: 'spacer' }
            ]
        }];

        TeaCo.views.Payments.superclass.initComponent.apply(this, arguments);

    },

    newPaymentHandler: function() {

        var self = this;

        // Show a 'loading' overlay mask
        self.setLoading(true);

        // Server side request to process payment. Expects a 'result' object with
        // either an error or an 'authorize payment' URL
        Ext.Ajax.request({
            url: '/controllers/payments.php',
            method: 'POST',
            params: 'action=createPayment',
            success: function(response){
                self.setLoading(false);

                // Open authorize payment screen
                TeaCo.provider.authorizePayment(response, {
                    success: function(response) {
                        // On successful authorisation, proceed to the next page
                        self.setLoading(false);
                        TeaCo.provider.removeIframe();
                        Ext.Msg.alert('Payment Success', JSON.stringify(response, null, '\t'));

                        Ext.getCmp('payment-status-button').enable();
                        Ext.getCmp('payment-refund-button').enable();
                    },
                    failure: function(error) {
                        self.setLoading(false);
                        TeaCo.provider.removeIframe();
                        Ext.Msg.alert('Error', JSON.stringify(error));
                    }
                });
            }
        });
    },

    newSubscriptionHandler: function() {

        var self = this;

        // Show a 'loading' overlay mask
        self.setLoading(true);

        // Server side request to process payment. Expects a 'result' object with
        // either an error or an 'authorize payment' URL
        Ext.Ajax.request({
            url: '/controllers/payments.php',
            method: 'POST',
            params: 'action=createSubscription',
            success: function(response){
                self.setLoading(false);

                // Open authorize payment screen
                TeaCo.provider.authorizePayment(response, {
                    success: function(response) {
                        // On successful authorisation, proceed to the next page
                        self.setLoading(false);
                        TeaCo.provider.removeIframe();
                        Ext.Msg.alert('Subscription Success', JSON.stringify(response, null, '\t'));

                        Ext.getCmp('subscription-status-button').enable();
                    },
                    failure: function(error) {
                        self.setLoading(false);
                        TeaCo.provider.removeIframe();
                        Ext.Msg.alert('Error', JSON.stringify(error));
                    }
                });
            }
        });
    },

    paymentStatusHandler: function() {
        var self = this;
        self.setLoading(true);

        Ext.Ajax.request({
            url: '/controllers/payments.php?action=paymentStatus',
            method: 'GET',
            success: function(response){
                self.setLoading(false);
                Ext.Msg.alert('Payment Status', response.responseText);
            }
        });
    },

    paymentRefundHandler: function() {
        var self = this;
        self.setLoading(true);

        Ext.Ajax.request({
            url: '/controllers/payments.php',
            method: 'POST',
            params: 'refund=true',
            success: function(response){
                self.setLoading(false);
                Ext.Msg.alert('Payment Refund', response.responseText);
            }
        });
    },

    subscriptionStatusHandler: function() {
        var self = this;
        self.setLoading(true);

        Ext.Ajax.request({
            url: '/controllers/payments.php?action=subscriptionStatus',
            method: 'GET',
            success: function(response){
                self.setLoading(false);
                Ext.Msg.alert('Subscription Status', response.responseText);
            }
        });
    }
});

Ext.reg('attPayments', TeaCo.views.Payments);
