TeaCo.views.WAP = Ext.extend(Ext.Panel, {

    layout: 'fit',

    // This function is run when initializing the component
    initComponent: function() {

        var self = this; // We need a reference to this instance for use in callbacks

        this.items = [{
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                title: 'WAP',
                items: {
                    xtype: 'button',
                    text: 'Back',
                    handler: function() {
                        Ext.getCmp('viewport').setActiveItem(0, {type: 'slide', direction: 'right'});
                    }
                }
            }],
            layout: 'vbox',
            items: [
                { xtype: 'spacer' },
                {
                    xtype: 'button',
                    text: 'New Wap Push',

                    handler: self.newWapHandler,
                    scope: self
                },
                { xtype: 'spacer' }
            ]
        }];

        TeaCo.views.WAP.superclass.initComponent.apply(this, arguments);

    },

    newWapHandler: function() {

        var self = this;
        self.setLoading(true);

        Ext.Ajax.request({
            url: '/controllers/wap.php',
            method: 'POST',
            success: function(response){

                self.setLoading(false);

                var resp = JSON.parse(response.responseText);
                if (resp.error) {
                    Ext.Msg.alert('Wap Push Error', JSON.stringify(resp, null, '\t'));
                } else {
                    Ext.Msg.alert('Wap Push Success', JSON.stringify(resp, null, '\t'));
                }
            }
        });

    }
});

Ext.reg('attWAP', TeaCo.views.WAP);
