<!DOCTYPE html>
 <html>
 <head>
	 <link rel="stylesheet" href="/resources/css/sencha-touch.css" type="text/css">
 </head>
 <body onload="parent.TeaCo.provider.failureCallback('<?= isset($_GET['error']) ? $_GET['error'] : "" ?>')" class="x-mask x-mask-gray">
     <div style="height: 300px">
         <div class="x-mask-loading">
             <div class="x-loading-spinner">
                 <span class="x-loading-top"></span>
                 <span class="x-loading-right"></span>
                 <span class="x-loading-bottom"></span>
                 <span class="x-loading-left"></span>
             </div>
             <div class="x-loading-msg">Loading...</div>
         </div>
     </div>
 </body>
</html>
