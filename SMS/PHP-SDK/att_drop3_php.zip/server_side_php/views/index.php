<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
  <head>
    <meta charset="utf-8">
    <title>Sencha AT&amp;T Test</title>
    <link rel="stylesheet" href="../public/resources/css/sencha-touch.css" type="text/css">
    <link rel="stylesheet" href="../public/css/style.css" type="text/css">

    <script type="text/javascript" src="../public/sencha-touch-debug.js"></script>

    <script type="text/javascript" src="../public/direct/Function.js"></script>
    <script type="text/javascript" src="../public/direct/DirectProxy.js"></script>
    <script type="text/javascript" src="../public/direct/DirectStore.js"></script>
    <script type="text/javascript" src="../public/direct/Direct.js"></script>
    <script type="text/javascript" src="../public/direct/Transaction.js"></script>
    <script type="text/javascript" src="../public/direct/Event.js"></script>
    <script type="text/javascript" src="../public/direct/Provider.js"></script>
    <script type="text/javascript" src="../public/direct/JsonProvider.js"></script>
    <script type="text/javascript" src="../public/direct/PollingProvider.js"></script>
    <script type="text/javascript" src="../public/direct/RemotingProvider.js"></script>

    <script type="text/javascript" src="../public/lib/SenchaProvider.js"></script>

    <script type="text/javascript" src="../public/app/app.js"></script>
    <script type="text/javascript" src="../public/app/controllers/index.js"></script>
    <script type="text/javascript" src="../public/app/views/kitchenSink.js"></script>

    <script type="text/javascript" src="../public/app/views/apiList.js"></script>
    <script type="text/javascript" src="../public/app/views/deviceInfo.js"></script>
    <script type="text/javascript" src="../public/app/views/deviceLocation.js"></script>
    <script type="text/javascript" src="../public/app/views/mms.js"></script>
    <script type="text/javascript" src="../public/app/views/payments.js"></script>
    <script type="text/javascript" src="../public/app/views/sms.js"></script>
    <script type="text/javascript" src="../public/app/views/wap.js"></script>
  </head>
  <body>
  </body>
</html>
