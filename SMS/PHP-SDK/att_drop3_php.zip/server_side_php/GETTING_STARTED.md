# Introduction (DES-SDK-014)
------------------------------------------------------------------------------

> The introduction section of the SDK document shall provide a value
> proposition for using the SDK.  AT&T and Sencha will work together to
> determine the value proposition.  The introduction shall also orient the
> developer user within the SDK;  highlighting the contents, and the next
> steps.  A prerequisites section shall be included.

## How to use this SDK (DES-SDK-042)

> The introduction section of the SDK document shall provide the developer
> information on how to use the SDK. This information shall also orient the
> developer user within the SDK;  highlighting the contents, and the next
> steps.

The AT&T REST APIs allows application developers to leverage powerful functionality in their apps such
as device location and payment processing.

The Sencha Provider library exposes these APIs for HTML 5 developers with a lightweight wrapper
consisting of a client and server component.

The server component is a standalone library handling the interaction with the AT&T API and is
available in multiple flavors including Ruby, PHP and Java. It can be used in conjunction with
a server side framework such as Ruby on Rails, Zend or Tomcat.

The client component interacts with the server to provide a seamless, cross platform experience for the
application developer.

## Overview of the architecture (DES-SDK-015)

> The introduction section shall provide a simple overview of the
> architecture.  

The SDK is split in to two components: Server side and Client side. The server side library is available in multiple flavors including Ruby, Java and PHP, each one providing native wrapper functions to the AT&T REST APIs. It is designed to be used in conjunction with a server side framework such as Ruby on Rails, PHP Zend or Java Tomcat.

The Client side component is optional and is used to complement Sencha Touch applications. Its job is to ease the process of interacting with the AT&T authorization screens by providing utility methods for displaying those screens and handling the response.

### Components

This project consists of 4 parts:

 - A PHP wrapper for AT&T's HTML5 APIs (in ./lib/sencha)
 - PHP scripts providing endpoints required for using the AT&T APIs (in ./controllers and ./views)
 - A sample Sencha Touch application demonstrating the Login and Payment APIs from start to finish (in ./public/app)
 - A javascript component for interacting with the server side (in ./public/lib/SenchaProvider.js)

### Prerequisites (DES-SDK-041)

>  A prerequisites section shall be available  which will provide a listing
>  of technologies that the developer should be familiar with.  

The developer should be familiar with PHP 5.

 - PHP 5.2

### Obtaining Application Credentials

In order to use the Sencha Provider library, you will need the following information:

  - A Client ID. This is the application ID you receive when registering your application with your provider.
  - A Client Secret. This is the 'secret key' you receive from your provider for authorization purposes.
  - A Shortcode. This is used for sending and receiving SMS and MMS messages.
  - An endpoint URL. This is the base API endpoint the library will be interacting with.

To obtain these

### Starting the example

1. Update `index.php` to use the IP address of the local machine (needed for callbacks from the AT&T api)
2. Update `index.php` to use the client ID, secret and shortcode provided by AT&T (the defaults should also work)
3. Navigate to http://your-ip-address:4567 from your webkit based browser or mobile device
   Please note, the URL *MUST* be the same as specified in the local_server variable in app.rb

### Further information

http://docs.sencha.com/touch - Sencha Touch documentation



## Overview of server architecture (DES-SDK-016)

> The introduction section shall provide a simple overview of server
> architecture. This shall describe the relationship between web apps and
> any network enablers which are meant to work with the web apps.  

The server side SDK provides a set of wrapper functions to the AT&T REST APIs. It consists of a main Provider class and several helper classes. The Provider class is responsible for issuing requests to AT&T and the Response class parses and normalizes the server response.

Each AT&T API has a corresponding method on the provider class, for example getToken, deviceLocation, sendSms, createPayment and wapPush. When one of these methods is called, a the appropriate JSON request is made to the AT&T server with the relevant data as the body of the request. The server response is parsed by the Response class which is then passed back to the client. These methods return an instance of the Response class which can be queried for data.

Here's an example of how we use the device location API:

    $response = $provider->getLocation('my_access_token', '4155556425')
    if ($response->isError()) {
      echo "Error! " . $response->error();
    } else {
      echo "Location: " . $response->data();
    }

Once the Provider class has been initialized with the application ID and secret, it is available for


# Tutorial
------------------------------------------------------------------------------

## How to set up the SDK (DES-SDK-018)

    The tutorial section shall provide the developer information on how to set
    up the developer environment, i.e. how to set up the SDK.  

## How to set up the directory structure (DES-SDK-019)

    Documentation - The tutorial section shall provide the developer
    information on how to set up a development directory structure in the
    local development environment.  It will explain what directories must be
    created, and where to place them in relation to other directories.

## How to create the files for the web app (DES-SDK-020)

    The tutorial section shall provide the developer information on how to
    create the files for the web app. It should describe all of the files that
    the developer needs to create for the sample project, and where to place
    them in their local directory structure. Sample code shall be part of the
    document code.  

## Creating an example web app (DES-SDK-017)

    The tutorial section of the SDK document shall provide a tutorial which
    shall describe to the developer every step that is necessary to create an
    example web app using the AT&T APIs using the new Black Flag elements
    created by Sencha.

## How to test the app (DES-SDK-022)

    The tutorial section shall provide the developer conceptual information on
    how to test the web app.  It will describe procedures the developer should
    take to deploy the app on the development environment, and how to run it
    to make sure the app works properly.


# Reference
------------------------------------------------------------------------------

## Miscellaneous info (DES-SDK-024)

    Provide the developer a reference area for miscellaneous information.
    Sample code shall be part of the document code.  


## API authentication for each Supported API (DES-SDK-025)

    This shall give overall guidance in how APIs in general are Authenticated
    in the Getting Started Guide, as well as give guidance specifically within
    each API Documentation

## Include clear references to API Documentation (DES-SDK-029)

    Provide the developer an API reference which details every API implemented
    that has been exposed to developers.  This would include the following:
    Syntax, Use Cases, Code Samples.



## Sencha Touch Server Side SDK

This library is contains several PHP classes that interface to the AT&T HTML5 APIs.

### Examples usage

First, initialize an instance:

		$provider = ProviderFactory::init(array(
		  "provider" => "att",
		  "client_id" => "c4c9084c6e9cb6ca01886a15e7dfd486",
		  "client_secret" => "a0725b93040cfe0e",
		  "local_server" => "http://127.0.0.1:4567"
		));

### Methods

#### oauthUrl(scope)

This method returns the AT&T oauth url needed for a user to authenticate. Example:

		url = $provider->oauthUrl($scope)

#### getToken(code)

Swaps an auth code returned by the AT&T oAuth callback for an access token which can be
used to access the AT&T APIs. Example:

		$response = $provider->getToken($code)
    		if ($response->isError()) {
      			echo "Error! " . $response->error();
    		} else {
      			echo "Got token " . $response->data()->access_token;
    		}

#### create_payment(options)

Initiates a new payment via AT&T's payment API and returns the resulting authorization URL.
Example:

  		$response = $provider->createPayment($_SESSION['token'], array(
    			"product_id" => "SenchaProduct60214",
    			"amount" => 1.29,
    			"description" => "Sencha Description",
    			"transaction_id" => "SenchaTransId" . time()
  		));
		
  		if ($response->isError()) {
    			echo "{\"error\": " . json_encode($response->error()) . "}";
  		} elseif ($response->data()->redirectUrl == "") {
    			echo "{\"error\": \"Payment Error\"}";
  		} else {
    			$_SESSION['payment_id'] = $response->data()->trxID;
    			echo "{\"redirect\": " . json_encode($response->data()->redirectUrl) . "}";
  		}



## Sencha Touch Client Side Provider Class

### Overview

Sencha Touch is a mobile application framework for building rich, native like applications using Javascript
and CSS that run on any smartphone or tablet equipped with a webkit based browser.

Sencha Touch applications consist of a single HTML file - DOM elements and content are created dynamically
with Javascript. As such, a Sencha Touch application only makes a single page request at startup. Any further
server interactions happen via AJAX.

This presents a problem when dealing with services such as oAuth which typically require that the client
browser is redirected to a third party website before being redirected back.

### IFrames

The Sencha Provider library deals with this problem by overlaying an iframe onto the content of the application.
Once the user has finished interacting with the third party service they are redirected back to a page on the local
web server. Since the domain of the iframe now matches that of the Sencha Touch application, the iframe has
permission to call functions from its 'parent' frame.

This means that authorizations for oauth and payments can be completed without leaving the Sencha Touch application.

This is the underlying mechanism employed by the Sencha Provider component to allow interaction with the AT&T APIs
without the user having to leave the Sencha Touch application.

### Usage

The Sencha Provider component should can be initialized like this:

		var provider = new Sencha.Provider();

There are 3 APIs currently implemented:

#### isAuthorized

This method is called to check if the user has an active access_token on the server. Usage:

		provider.isAuthorised('PAYMENT', {
			success: function() {
				alert('Already authenticated for Payments');
			},
			failure: function() {
				alert('Not already authenticated for Payments');
			}
		})

#### authorizeApp

This method opens an authorization screen for users to give permission to the application
for a given scope. Usage:

		provider.authorizeApp('PAYMENT', {
			success: function() {
				alert('Application authenticated for Payments');
			},
			failure: function() {
				alert('Application not authenticated for Payments');
			}
		})

#### authorizePayment

This method takes the response from a server side request to process a payment and presents
and authorization screen to the user. Usage:

		Ext.Ajax.request({
		    url: '/controllers/payments.php',
		    method: 'POST',
		    params: 'action=createPayment',
		    success: function(response){
		        provider.authorisePayment(response, {
		            success: function() {
		                alert('Payment successfully authorised');
		            },
		            failure: function() {
		                alert('Payment not authorised');
		            }
		        });
		    }
		});




## Example Application File Topography

Here is a brief description of all the files in this release and their purpose:

### Server side library

./lib/sencha
  All server side php code is stored in this directory.
./lib/sencha/README.md
  An overview of the PHP Provider library
./lib/sencha/service_provider
  Contains code for different providers, currently only AT&T is supported
./lib/sencha/service_provider/ProviderFactory.php
  Manages initialization of a Sencha Touch Provider. Returns an instance of
  a provider sub-class
./lib/sencha/service_provider/Base.php
  The AT&T API wrapper helper functions reside in this file
./lib/sencha/service_provider/Sencha_ServiceProvider_Base_Att.php
  Contains API wrapper methods for:
	- Device Info
	- Location
	- MMS
	- oAuth
	- Payment oAuth
	- SMS
	- WAP

./lib/sencha/service_provider/Response.php
  Parses and normalizes AT&T server responses
./lib/sencha/service_provider/MiniMime.php
  A helper library for managing the creation of Mime strings
./lib/sencha/service_provider/Debug.php
  A helper library for writing debugging information to a file
./lib/sencha/service_provider/config.php
  A script to define constants such as debugging on/off and where to log files in the filesystem

### Sencha Touch Client Side Provider library

./public/lib/README.md
  An overview of the Sencha client library
./public/lib/SenchaProvider.js
  The client side Sencha Touch provider library

### Server Side Example App

./index.php
  The initial script creates an instance of a Provider and redirects to
  ./views/index.php which in turn loads the app
./views/callback.php
  When an AT&T callback is successful this page renders within the AT&T iframe
  and calls the 'success' function in the parent frame (the Sencha Touch app)
./views/error.php
  As above, but for Errors
./views/index.php
  This is the HTML required to render for the Sencha Touch application to launch
./views/redirect.php
  This will be rendered into an iframe initially when the page needs to redirect,
  in order that the user is presented with a loading screen rather than a blank
  white pane while waiting for a remote page request to load.

### Client Side Example App

./public/app/app.js
  The Sencha Touch application definition
./public/app/controllers/index.js
  The primary controller for the Sencha Touch example application
./public/app/views/kitchenSink.js
  The main components used in the Sencha Touch Example. The primary
  interactions with the client side library happen here
./public/app/views/apiList.js
  Shows the list of APIs that can be exercised
./public/app/views/deviceInfo.js
  The button and handler for testing the Device Info API
./public/app/views/deviceLocation.js
  The button and handler for testing the Device Location API
./public/app/views/mms.js
  The buttons and handlers for testing the MMS API
./public/app/views/payments.js
  The buttons and handlers for testing the Payments API
./public/app/views/sms.js
  The buttons and handlers for testing the SMS API
./public/app/views/wap.js
  The buttons and handlers for testing the Wap API
./public/css/style.css
  The stylesheet for the Sencha Touch example app
./public/direct
  Ext.Direct is a dependency for the Sencha Touch Client Provider library
./public/images
  Background images required for the Example app.

### Sencha Touch Library

./public/sencha-touch.js
  The Sencha Touch library minifed. For use in production environments
./public/sencha-touch-debug.js
  The Sencha Touch library (for use during development)
./public/resources
  The Sencha Touch resources directory. Ships with Sencha Touch



## Example Application Endpoints

The purpose of the PHP application is to make available the endpoints
that must be present in order to successfully interact with the AT&T HTML5 APIs

This sample exposes the following endpoints:

`/index.php`:
	This serves the sample Sencha Touch application

`/controllers/auth.php?url`:
	Used by the client library to generate the oAuth URL the client must
	be redirected to in order to authorize an application to interact with
	the AT&T APIs

`/controllers/auth.php?check`:
	Used to check if the client has already authenticated with AT&T

`/controllers/callback.php`:
	AT&T will callback to this endpoint when a user has successfully authenticated

`/controllers/payments.php`:
	Post requests to this endpoint initiate a New Payment request to AT&T using the
	PHP library supplied by Sencha

	- creatPayment
	- paymentStatus
	- createSubscription
	- subscriptionStatus

`/controllers/att_redirect.php`:
	This is designed to be loaded from within an iFrame. It presents a loading
	screen while the third party page is loaded. This is for a more seamless user
	experience: the user is presented a loading screen so they know the action
	they have taken is working.

`/controllers/payments.php?deliver`:
	A successful payment authorization will redirect to this endpoint

`/controllers/payments.php?cancel`:
	An unsuccessful payment authorization will redirect to this endpoint



## Standards list (DES-SDK-028)

    The 'Getting Started Guide' shall provide the developer links to standards
    with which the web app platform is compliant.  A brief explanation should
    accompany each link. This is required via Release notes and should be part
    of any present and future drop (Add to R1 general requirements)

