<?php
require_once("config.php");
function exception_handler($exception) {
 echo "Fatal error: " , $exception->getMessage(), "\n";
}
set_exception_handler("exception_handler");

# the base class for the AT&T provider
class Sencha_ServiceProvider_Base_Att extends Base {

  private $client_id = "";
  private $client_secret = "";
  private $local_server = "";
  private $base_url = "";
  private $shortcode = "";

  public function __construct($config) {

    if (!$config['client_id']) throw new Exception("client_id must be set");
    if (!$config['client_secret']) throw new Exception("client_secret must be set");
    if (!$config['local_server']) throw new Exception("local_server must be set");
    if (!$config['host']) throw new Exception("host must be set");
    if (!$config['shortcode']) throw new Exception("shortcode must be set");

    $this->client_id = $config['client_id'];
    $this->client_secret = $config['client_secret'];
    $this->local_server = $config['local_server'];
    $this->base_url = $config['host'];
    $this->shortcode = $config['shortcode'];

    if (DEBUG) {
      DEBUG::init();
      DEBUG::write("\nAT&T Provider initialized.\n");
      DEBUG::dumpBacktrace();
      DEBUG::write("API endpoint: $this->base_url\nClient ID: $this->client_id\nClient Secret: $this->client_secret\nLocal Server: $this->local_server\nShortcode: $this->shortcode\n\n");
      DEBUG::end();
    }
  }

  /**
    OAuth
  */
  public function oauthUrl($scope) {
    # Generate the oauth redirect URL depending on the scope requested by the client.
    # The scope is specified as a parameter in the GET request and passed to the provider
    # library to obtain the appropriate OAuth URL
    if (is_array($scope)) {
      # $scope will be an array when called by the direct router
      $scope = $scope[0];
    }
    return "$this->base_url/oauth/authorize?scope=$scope}&client_id={$this->client_id}&type=web_server&redirect_uri={$this->local_server}/controllers/callback.php";
  }

  public function getToken($code) {
    # Retrieves and access token from AT&T once the user has authorised the application and returned with an auth code
    return $this->json_get("$this->base_url/oauth/access_token?client_id={$this->client_id}&client_secret={$this->client_secret}&code=$code");
  }

  public function deviceInfo($data) {
    return $this->json_get("$this->base_url/1/devices/tel:$data[1]/info?access_token=$data[0]");
  }

  public function deviceLocation($data) {
    return $this->json_get("$this->base_url/1/devices/tel:$data[1]/location?requestedAccuracy=$data[2]&access_token=$data[0]");
  }

  /**
    SMS
  */
  public function sendSms($data) {
    return $this->json_post("$this->base_url/1/messages/outbox/sms?access_token=$data[0]", array("address" => "tel:$data[1]", "message" => $data[2]));
  }

  public function sendSmsGsma($data) {
    return $this->json_post("$this->base_url/gsma/1/smsmessaging/outbound/$this->shortcode/requests?access_token=$data[0]", array("address" => "tel:$data[1]", "message" => $data[2]));
  }

  public function smsStatus($data) {
    return $this->json_get("$this->base_url/1/messages/outbox/sms/$data[1]?access_token=$data[0]");
  }

  public function receiveSms($data) {
    return $this->json_get("$this->base_url/1/messages/inbox/sms?access_token=$data[0]&registrationID=$this->shortcode&from=json");
  }

  /**
    Payments and Subscriptions
  */
  public function createPayment($token, $options) {
    return $this->json_post("$this->base_url/1/payments/transactions?access_token=$token", $this->payment_options($options));
  }

  public function createSubscription($token, $options) {
    return $this->json_post("$this->base_url/1/payments/transactions?access_token=$token", $this->payment_options($options, true));
  }

  public function paymentStatus($token, $transaction_id) {
    return $this->json_get("$this->base_url/1/payments/transactions/$transaction_id?access_token=$token");
  }

  public function subscriptionStatus($token, $subscription_id) {
    return $this->json_get("$this->base_url/1/payments/transactions/$subscription_id?access_token=$token");
  }

  public function paymentRefund($token, $options) {
/*
        %w(transaction_id reason code).each do |arg|
          raise ArgumentError, "#{arg} must be set" unless options[arg.to_sym]
        end
*/
    if (!$options['transaction_id']) throw new Exception("transaction_id must be set");
    if (!$options['reason']) throw new Exception("reason must be set");
    if (!$options['code']) throw new Exception("code must be set");
    
    return $this->json_post("$this->base_url/1/payments/transactions/{$options['transaction_id']}?access_token=$token&action=refund", array("refundReasonText" => $options['reason'], "refundReasonCode" => $options['code']));
  }

  private function payment_options($options, $subscription = false) {
    $response = array(
      "amount" => $options['amount'],
      "category" => 1,
      "channel" => 'MOBILE_WEB',
      "currency" => 'USD',
      "description" => $options['description'],
      "merchantProductID" => $options['product_id'],
      "merchantApplicationID" => $this->client_id,
      "externalMerchantTransactionID" => $options['transaction_id'],
      "purchaseOnNoActiveSubscription" => false,
      "merchantCancelRedirectUrl" => "$this->local_server/controllers/payments.php?cancel",
      "merchantFulfillmentRedirectUrl" => "$this->local_server/controllers/payments.php?deliver",
      "transactionStatusCallbackUrl" => "$this->local_server/controllers/payments.php?notify",
      "autoCommit" => true
    );

    if ($subscription) {
      $response = array_merge($response, array(
        "subscriptionRecurringNumber" => $options['recurrences'],
        "subscriptionRecurringPeriod" => $options['recurrence_period'],
        "subscriptionRecurringPeriodAmount" => $options['recurrence_interval'],
        "merchantSubscriptionIdList" => $options['subscription_id']
      ));
    }

    return $response;
  }

  /**
    MMS
  */
  public function sendMms($token, $tel, $file_type, $file_name, $encoded_file, $priority) {
    $mimeContent = new MiniMime();
    $mimeContent->add_content(array(
      "type" => "application/json",
      "content" => "{ 'address' : 'tel:$tel', 'subject' : 'MMS', 'priority': '$priority' }"
    ));

    $mimeContent->add_content(array(
      "type" => $file_type,
      "headers" => array(
         "Content-Transfer-Encoding" => "base64",
         "Content-Disposition" => "attachment; name=$file_name"
      ),
      "content_id" => "<$file_name>",
      "content" => $encoded_file
    ));
    
    return $this->json_post_mime("$this->base_url/1/messages/outbox/mms?access_token=$token", $mimeContent);
  }

  public function mmsStatus($data) {
    return $this->json_get("$this->base_url/1/messages/outbox/mms/$data[1]?access_token=$data[0]");
  }

  /**
    WAP
  */
  public function wapPush($token, $tel, $xml) {
     $mimeContent = new MiniMime();

     $mimeContent->add_content(array(
       "type" => "text/xml",
       "content" =>
            "<wapPushRequest>\n" .
            "  <addresses>\n" .
            "     <address>tel:$tel</address>\n" .
            "  </addresses>\n" .
            "  <subject>WAP</subject>\n" .
            "  <priority>High</priority>\n" .
            "</wapPushRequest>"
      ));

      $mimeContent->add_content(array(
        "type" => "text/xml",
        "content" =>
          "Content-Disposition: form-data; name=\"PushContent\"\n" .
          "Content-Type: text/vnd.wap.si\n" .
          "Content-Length: 12\n" .
          "X-Wap-Application-Id: x-wap-application:wml.ua\n" .
          "\n$xml"
      ));

      return $this->json_post_mime("$this->base_url/1/messages/outbox/wapPush?access_token=$token", $mimeContent);
  }

  public function __call($name, $args) {
    preg_match("/^direct_(.*)$/", $name, $matches);
    if ($method = $matches[1]) {
      # $args is an array of the passed params (this is important to know since we're calling methods using call_user_func_array())
      # also, return value must be cast to an object as it will then be merged into another object
      $response = $this->$method($args);
      if ($response instanceof Response) {
        if ($response->isError()) {
          return (object) array("error" => $response->error());
        } else {
          return (object) array("result" => $response->data());
        }
      } else {
        # for APIs like oauthUrl that only return a string and don't wrap a cURL response in a Response object, $response will be a string
        return (object) array("result" => $response);
      }
    } else {
      return (object) array("error" => "No such method");
    }
  }
}
?>
