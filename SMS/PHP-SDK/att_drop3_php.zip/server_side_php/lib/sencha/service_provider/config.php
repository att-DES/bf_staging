<?php
define("DEBUG", "1");
define("DEBUG_LOGGER", "/usr/local/www/providerapi/server_side_php/lib/sencha/service_provider/debug_log");
?>
